# Introduction 
This project provides examples as well as the Azure Resource Manager (ARM) templates for deploying resources into Azure for Corteva 

ARM templates are a method of defining infrastructure as code which provides the advantages of - 
	Control and tracking of changes to infrastructure (infrastructure as code)
	Controlled consistency of infrastructure between environments 

# Getting Started
Learn about ARM templates https://docs.microsoft.com/en-us/azure/azure-resource-manager/ 

# Contents 

/agents             VM agents
/deploymentScripts  Example scripts to be used during releases that perform actions against Azure resources 
/examples           Examples of ARM templates that consume the Corteva templates to assist app teams in deploying their Azure resources 
/templates          Corteva ARM templates for deploying resources into the Corteva Azure (always reference the the latest version)

# Need More? 
A Wiki of How To articles - https://dupont.sharepoint.com/teams/teams_azure_app/howto/Lists/Posts/AllPosts.aspx 

We have a working example of deploying web apps called IT-WebAppDemonstration that demonstrates best practices for releasing web apps into Azure
Information can be found here  - https://dupont.sharepoint.com/teams/teams_azure_app/howto/Lists/Posts/Post.aspx?ID=35

# Not seeing a resource I need  

The resources available in Azure are ever changing. If we don't have a template for a resource contact us at DL-AzureSupport@pioneer.com  
