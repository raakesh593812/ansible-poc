configuration SQLCluster
{
    param
    (
        [Parameter(Mandatory)]
        [Boolean]$IsClustered,
        [Parameter(Mandatory)]
        [String]$DomainName,
        [Parameter(Mandatory)]
        [String]$DomainNameSuffix,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
        [Parameter(Mandatory)]
        [String]$ClusterName,
        [Parameter(Mandatory)]
        [String]$ClusterIP,
        [Parameter(Mandatory)]
        [String]$ClusterIlbIP,
        [Parameter(Mandatory)]
        [String]$FileShareListenerIP,
        [Parameter(Mandatory)]
        [String]$FileShareWitness,
        [Parameter(Mandatory)]
        [String]$NamePrefix,
        [Parameter(Mandatory)]
        [String]$NodeIndex,
        [Parameter(Mandatory)]
        [String]$SapSid,
        [Parameter(Mandatory)]
        [String]$SecondaryNodeName,
        [Parameter(Mandatory)]
        [Array]$DataVolumeLUNs,
        [Parameter(Mandatory)]
        [int]$LogVolumeLUN,
        [Parameter(Mandatory)]
        [String]$witnessStorageName,	
        [Parameter(Mandatory)]
        [String]$witnessStorageEndpoint,
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$witnessStorageKey,
        [String]$DomainNetbiosName = (Get-NetBIOSName -DomainName $DomainName)
    )

    Import-DscResource -ModuleName xSqlServer
 
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    $windowsVersion = [System.Environment]::OSVersion.Version.Major + [System.Environment]::OSVersion.Version.Minor/10 #6.1=2008R2, 6.2=2012, 6.3=2012R2, 10.0=2016    
    
    Node localhost
    {
        LocalConfigurationManager {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature FC {
            Name   = "Failover-Clustering"
            Ensure = "Present"
        }

        WindowsFeature ADPS {
            Name   = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        WindowsFeature FS {
            Name   = "FS-FileServer"
            Ensure = "Present"
        }

        if($windowsVersion -eq 6.1) {
            WindowsFeature FCPS {
                Name   = "RSAT-Clustering"
                Ensure = "Present"
            }
        }

        if($windowsVersion -gt 6.1) {
            WindowsFeature FailoverClusterTools { 
                Ensure    = "Present" 
                Name      = "RSAT-Clustering-Mgmt"
                DependsOn = "[WindowsFeature]FC"
            } 

            WindowsFeature FCPS {
                Name   = "RSAT-Clustering-PowerShell"
                Ensure = "Present"
            }

			WindowsFeature 'RSAT-Clustering-CmdInterface' {
				Ensure = 'Present'
				name   = 'RSAT-Clustering-CmdInterface'
			}  
        }

        Package VCRedist2005SP1 {
            Ensure    = 'Present'
            Name      = "Microsoft Visual C++ 2005 Redistributable"
            Path      = "$PSScriptRoot\installers\2005SP1\vcredist_x86.exe"
            ProductId = '7299052B-02A4-4627-81F2-1818DA5D550D'
            Arguments = "/Q"
        }

        Package VCRedist2010SP1 {
            Ensure    = 'Present'
            Name      = "Microsoft Visual C++ 2010  x86 Redistributable - 10.0.40219"
            Path      = "$PSScriptRoot\installers\2010SP1\vcredist_x86.exe"
            ProductId = 'F0C3E5D1-1ADE-321E-8167-68EF0DE699A5'
            Arguments = "/q"
        }

        Package VCRedist2013 {
            Ensure    = 'Present'
            Name      = "Microsoft Visual C++ 2013 x86 Minimum Runtime - 12.0.21005"
            Path      = "$PSScriptRoot\installers\2013\vcredist_x86.exe"
            ProductId = '13A4EE12-23EA-3371-91EE-EFB36DDFFF3E'
            Arguments = "/quiet"
        }

        

        Script SetPolicies{
            SetScript = {
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name MaxDisconnectionTime -Value  86400000
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" -Name MaxIdleTime -Value  86400000
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name shutdownwithoutlogon -Value  0
                New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" -Force
                New-Item -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Force
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name NoAutoUpdate -Value 1
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name NoAutoRebootWithLoggedOnUsers -Value 1
                New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Force
                Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -Name NoCLose -Value 1 
            }
            TestScript = {  if ((Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer" -ErrorAction SilentlyContinue).NoCLose -eq 1) {$true} else {$false} }
            GetScript  = { }
        }
        
        Script SetIpInfoText {   
            SetScript = {
                NEW-ITEM -Name "IpInfo.txt" -Path "c:\" -ItemType file -force | OUT-NULL 
                ADD-CONTENT -Path "c:\IpInfo.txt" "DB00 Cluster IP: $($using:ClusterIP)"
                ADD-CONTENT -Path "c:\IpInfo.txt" "DB00 ILB IP: $($using:ClusterIlbIP)"
			    ADD-CONTENT -Path "c:\IpInfo.txt" "Temp Listener IP: $($using:FileShareListenerIP)"
		    }   
            TestScript = { if((Get-Content 'c:\IpInfo.txt' -First 1 -ErrorAction SilentlyContinue) -match "DB00 Cluster IP: $($using:ClusterIP)"){ Return $true } else { return $false } }
            GetScript  = { }
        } 

		if ($sapSid -ne 'XXX')
		{
			Group AddLocalAdmins {
				GroupName        = 'Administrators'   
				Ensure           = 'Present'             
				MembersToInclude = "$DomainName\sapservice$($sapSid)", "$DomainName\sap_$($sapSid)_GlobalAdmin", "$DomainName\$($sapSid)adm"
				Credential       = $DomainCreds
			}
		}
        
        Script MachineKeysAcl {
            SetScript  = {
                $machineKeysPath = 'C:\ProgramData\Microsoft\Crypto\RSA\MachineKeys\'
                $keys = Get-ChildItem $machineKeysPath
                $keys | % { $acl = Get-Acl $_.FullName; $acl.SetOwner([System.Security.Principal.NTAccount]'Administrators'); Set-Acl -Path $_.FullName -AclObject $acl }
                $acl = Get-Acl -Path $machineKeysPath
                $permissions = 'Administrators', 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow'
                $rule = New-Object -TypeName System.Security.AccessControl.FileSystemAccessRule -ArgumentList $permissions
                $acl.SetAccessRule($rule)
                $acl.SetOwner([System.Security.Principal.NTAccount]'Administrators')
                Set-Acl -Path $machineKeysPath -AclObject $acl
            }
            TestScript = {
                $machineKeysPath = 'C:\ProgramData\Microsoft\Crypto\RSA\MachineKeys\'                    
                if ((Get-Acl $machineKeysPath).Owner -eq 'BUILTIN\Administrators') { $true } else { $false }
            }
            GetScript  = {
                $machineKeysPath = 'C:\ProgramData\Microsoft\Crypto\RSA\MachineKeys\'
                return @{ Result = (Get-Acl $machineKeysPath).Owner }
            }
        }        

        if ($IsClustered) {
            Script AddDomainJoinUser {
                SetScript  = {
                    $AdminGroup = [ADSI]"WinNT://$($env:computername)/Administrators,group"
                    $User = [ADSI]"WinNT://$($using:DomainName)/$($using:Admincreds.UserName),User"
                    Write-Verbose "Adding user $($usin:DomainName)/$($using:Admincreds.UserName) ($($User.Path)) to Administrators group on $($env:computername)"
                    $AdminGroup.Add($User.Path)
                }
                TestScript = {
                    $AdminGroup = [ADSI]"WinNT://$($env:computername)/Administrators,group"
                    if (($adminGroup.psbase.Invoke("Members") | % { $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null) }) -contains $using:Admincreds.UserName) {
                        Write-Verbose "$($using:Admincreds.UserName) is in Administrators group"
                        return $true
                    }
                    else {
                        Write-Verbose "$($using:Admincreds.UserName) is not in Administrators group"
                        return $false
                    }
                }
                GetScript  = { }
            }

            if ($NodeIndex -eq 0 ) {
            Script FailoverCluster {
                SetScript            = {
                    $nodes = @($env:computername, $using:SecondaryNodeName)
                        Write-Verbose "Cluster $($using:ClusterName) not found, creating with nodes $nodes"
                        if($windowsVersion -eq 6.1){
                            New-Cluster -Name $using:ClusterName -Node $nodes -StaticAddress $using:ClusterIP -NoStorage -ErrorAction Stop                        
                        }else {
                        New-Cluster -Name $using:ClusterName -Node $nodes -StaticAddress $using:ClusterIP -NoStorage -Force -ErrorAction Stop
                        }
                        if ( -not (Get-Cluster)) {
                            throw 'Cluster creation failed. Please verify output of ''Get-Cluster'' command'
                        }

                        Write-Verbose -Message "Created Cluster $using:ClusterName"
                    }
                TestScript           = {
                        $cluster = Get-Cluster -Name $using:ClusterName -Domain $using:DomainName -ErrorAction SilentlyContinue
                    if ($cluster) {
                        Write-Verbose "Found cluster $($using:ClusterName)"
                        return $true
                    }
                    else {
                        Write-Verbose "Cluster $using:ClusterName not found"
                    }

                    return $false
                }
                GetScript            = { }
                PsDscRunAsCredential = $DomainCreds
                DependsOn            = "[Script]MachineKeysAcl", "[Script]AddDomainJoinUser"
            }

                Script DBClusterListenerADObject {
                    
                    SetScript  = {
                        $clusterNameObject = Get-ADComputer -Identity $using:ClusterName
                        $DBClusterListenerName = "{0}DB" -f $using:NamePrefix
                        $DBClusterListenerSamAccountName = "{0}DB$" -f $using:NamePrefix
                        $OU = "OU=Azure,OU=Servers,DC={0},DC={1}" -f $using:DomainName, $using:DomainNameSuffix
                        New-ADComputer -Name $DBClusterListenerName -SAMAccountName $DBClusterListenerSamAccountName -Path $OU -Enabled $true -Description "DB Cluster Listener" 

                        $adRights = [System.DirectoryServices.ActiveDirectoryRights] "GenericAll"
                        $type = [System.Security.AccessControl.AccessControlType] "Allow"
                        $inheritanceType = [System.DirectoryServices.ActiveDirectorySecurityInheritance] "All"
                        $identity = [System.Security.Principal.IdentityReference] ($clusterNameObject.SID)
                        $ace = New-Object System.DirectoryServices.ActiveDirectoryAccessRule $identity,$adRights,$type,$inheritanceType                    
                        $aclPath = "AD:CN={0},{1}" -f $DBClusterListenerName, $OU
                        $acl = Get-Acl -Path $aclPath
                        $acl.AddAccessRule($ace)
                        Set-ACL -AclObject $acl -Path $aclPath
                     }
                    TestScript = { 
                        try {
                            $DBClusterListenerName = "{0}DB" -f $using:NamePrefix
                            $clusterNameObject = Get-ADComputer -Identity $DBClusterListenerName
                            if ($clusterNameObject) {
                                Write-Verbose "Found db server ad computer"
                                return $true
                            }
                            else {
                                Write-Verbose "Db server ad computer not found"
				return $false
                            }
                        }
                        catch {
                            return $false
                        }

                        return $false
                     }
                    GetScript  = { }
		    PsDscRunAsCredential = $DomainCreds
                    DependsOn  = "[script]FailoverCluster"
                }
           
            if($windowsVersion -gt 6.3) {
                Script Witness {
                    SetScript  = {
                        Write-Verbose "Setting Cloud Witness to $($using:witnessStorageName)"
                        Set-ClusterQuorum -CloudWitness -AccountName $using:witnessStorageName -AccessKey ($using:witnessStorageKey).GetNetworkCredential().Password -Endpoint $using:witnessStorageEndpoint
                    }
                    TestScript = "(Get-ClusterQuorum).QuorumResource.Name -eq 'Cloud Witness'"
                    GetScript  = "@{Ensure = if ((Get-ClusterQuorum).QuorumResource.Name -eq 'Cloud Witness') {'Present'} else {'Absent'}}"
                    DependsOn  = "[script]FailoverCluster"
                }
            }
            else {
                Script WitnessFolder {
                    SetScript  = {
                        Write-Verbose "Creating FileShare Witness folder in $($using:FileShareWitness)"                        
                        New-Item $using:FileShareWitness -Type Directory
                        Write-Verbose "Setting witness folder permissions"
                        $acl = Get-Acl $using:FileShareWitness
                        $accessRule = New-Object  system.security.accesscontrol.filesystemaccessrule("$($using:ClusterName)$","Modify","Allow")
                        $acl.AddAccessRule($accessRule)
                        Set-Acl $using:FileShareWitness $acl
                    }
                    TestScript = {
                        if(Get-Item -Path $using:FileShareWitness -ErrorAction SilentlyContinue) { 
                            return $true 
                        } 
                        else { 
                            return $false 
                        }
                    }
                    GetScript  = "@{Ensure = if ((Get-ClusterQuorum).QuorumResource.Name -eq 'File Share Witness') {'Present'} else {'Absent'}}"
                    PsDscRunAsCredential = $DomainCreds
                    DependsOn  = "[script]FailoverCluster"
                }
                
                Script Witness {
                    SetScript  = {
                        Write-Verbose "Setting FileShare Witness to $($using:FileShareWitness)"                        
                        Set-ClusterQuorum -NodeAndFileShareMajority $($using:FileShareWitness)
                    }
                    TestScript = "(Get-ClusterQuorum).QuorumResource.Name -eq 'File Share Witness'"
                    GetScript  = "@{Ensure = if ((Get-ClusterQuorum).QuorumResource.Name -eq 'File Share Witness') {'Present'} else {'Absent'}}"
                    DependsOn  = "[script]WitnessFolder"
                }
            }

                if($windowsVersion -gt 6.1) {
            Script IncreaseClusterTimeouts {
                SetScript  = "(Get-Cluster).SameSubnetDelay = 2000; (Get-Cluster).SameSubnetThreshold = 15; (Get-Cluster).CrossSubnetDelay = 3000; (Get-Cluster).CrossSubnetThreshold = 15"
                TestScript = "(Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15"
                GetScript  = "@{Ensure = if ((Get-Cluster).SameSubnetDelay -eq 2000 -and (Get-Cluster).SameSubnetThreshold -eq 15 -and (Get-Cluster).CrossSubnetDelay -eq 3000 -and (Get-Cluster).CrossSubnetThreshold -eq 15) {'Present'} else {'Absent'}}"
                DependsOn  = "[Script]Witness"
            }
        }        
            }

            Script WaitForCluster {
                SetScript  = {
                    $RetryIntervalSec = 10
                    $RetryCount = 60

                    for ($count = 0; $count -lt $RetryCount; $count++) {
                        try { 
                            if ((Get-ClusterNode -Name $env:computername -ErrorAction SilentlyContinue).State -eq 'Up') {
                                Write-Verbose -Message "Cluster is available and node is up"
                                $clusterFound = $true
                                break;
                            }            
                        }
                        catch {
                            Write-Verbose -Message "Cluster not found. Will retry again after $RetryIntervalSec sec"
                        }
            
                        Write-Verbose -Message "Cluster not found. Will retry again after $RetryIntervalSec sec"
                        Start-Sleep -Seconds $RetryIntervalSec
                    }

                    if (! $clusterFound) {
                        throw "Cluster not found after $count attempts with $RetryIntervalSec sec interval"
                    }
                }
                TestScript = {
                    if ((Get-ClusterNode -Name $env:computername -ErrorAction SilentlyContinue).State -eq 'Up') {
                        return $true
                    }

                    return $false
                }
                GetScript  = { }
            }

            Script RemoveDomainJoinUser {
                SetScript  = {
                    Write-Verbose "Removing domain join user from administrators group on $($env:computername)"
                    $AdminGroup = [ADSI]"WinNT://$($env:computername)/Administrators,group"
                    Write-Verbose "Removing $($using:Admincreds.UserName) from $($AdminGroup.Path)"
                    $User = [ADSI]"WinNT://$($using:DomainName)/$($using:Admincreds.UserName),User"
                    $AdminGroup.Remove($User.Path)
                }
                TestScript = {
                    Write-Verbose "Checking $($env:computername) for domain join account"
                    $AdminGroup = [ADSI]"WinNT://$($env:computername)/Administrators,group"
                    Write-Verbose "Checking $($AdminGroup.Path) for $($using:Admincreds.UserName)"
                    if (($adminGroup.psbase.Invoke("Members") | % { $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null) }) -contains $using:Admincreds.UserName) {
                        Write-Verbose "$($using:Admincreds.UserName) is in Administrators group"
                        return $false
                    }
                    else {
                        Write-Verbose "$($using:Admincreds.UserName) is not in Administrators group"
                        return $true
                    }
                }
                GetScript  = { }
                DependsOn  = "[Script]WaitForCluster"
            }
        
        }

    }

}

function Get-NetBIOSName { 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length = $DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length = 15
        }
        return $DomainName.Substring(0, $length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0, 15)
        }
        else {
            return $DomainName
        }
    }
}