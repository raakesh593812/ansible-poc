$ErrorActionPreference = 'Stop'
# disable verbose logging to speed up module loading
$VerbosePreferenceOriginal = $VerbosePreference
$VerbosePreference = "SilentlyContinue"
Import-Module AzureRM.Profile
Import-Module AzureRM.Resources
Import-Module AzureRM.KeyVault
Import-Module AzureRM.Storage
Import-Module Azure.Storage
$VerbosePreference = $VerbosePreferenceOriginal

$connectionName = "SPNConnection"
try
{
    # Get the connection "AzureRunAsConnection "
    $servicePrincipalConnection=Get-AutomationConnection -Name $connectionName         

    "Logging in to Azure..."
    Add-AzureRmAccount `
        -ServicePrincipal `
        -TenantId $servicePrincipalConnection.TenantId `
        -ApplicationId $servicePrincipalConnection.ApplicationId `
        -CertificateThumbprint $servicePrincipalConnection.CertificateThumbprint `
        -SubscriptionId $servicePrincipalConnection.SubscriptionId
}
catch {
    if (!$servicePrincipalConnection)
    {
        $ErrorMessage = "Connection $connectionName not found."
        throw $ErrorMessage
    } else{
        Write-Error -Message $_.Exception
        throw $_.Exception
    }
}

$StorageAccount = Get-AutomationVariable -Name "storageAccountName"
$keyVaultName = Get-AutomationVariable -Name "keyVaultName"

$StorageResourceGroup = (Find-AzureRmResource -ResourceType "Microsoft.Storage/StorageAccounts" -ResourceNameEquals $StorageAccount).ResourceGroupName

Write-Verbose "Updating Storage Keys for Storage Account $StorageAccount in ResourceGroup $StorageResourceGroup"

#Rotate Key Two slilently
Write-Verbose "Attempting to update Key 1"
New-AzureRmStorageAccountKey -ResourceGroupName $StorageResourceGroup -Name $StorageAccount -KeyName key2 | Out-Null
#Rotate Key One and keep value to set new SAS token
Write-Verbose "Attempting to update Key 2"
$NewStorageKeys = New-AzureRmStorageAccountKey -ResourceGroupName $StorageResourceGroup -Name $StorageAccount -KeyName key1

$context = New-AzureStorageContext -StorageAccountName $StorageAccount -StorageAccountKey $NewStorageKeys.keys[0].value

$SASExpiration = (Get-Date).ToUniversalTime().AddDays(7)

$SASURI = New-AzureStorageAccountSASToken -context $context -Service Blob -ResourceType Object -Permission r -StartTime (Get-Date).ToUniversalTime() -ExpiryTime $SASExpiration
$Secret = ConvertTo-SecureString "$SASURI&sr=b" -AsPlainText -Force
Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name "templates-read" -SecretValue $Secret -Expires $SASExpiration
