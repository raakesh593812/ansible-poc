﻿param (
    [string] [Parameter(Mandatory=$true)] $resourceGroupName,
    [string] [Parameter(Mandatory=$true)] $storageAccountName,
    [array] [Parameter(Mandatory=$true)] $containers,
    [string] [Parameter(Mandatory=$true)] $KeyVaultName

)

Set-AzureRmCurrentStorageAccount -ResourceGroup $resourceGroupName -Name $storageAccountName

foreach ($containerName in $containers)
{
    $container = Get-AzureStorageContainer -Name $containerName -ErrorAction SilentlyContinue

    if ($container)
    {
        Write-verbose "Container already exists. Checking to make sure permissions are set to private"
        if($container.PublicAccess -ne "off")
        {
            Write-verbose "Container permissions currently set to $($container.PublicAccess). Changing to Private (off)"
            Set-AzureStorageContainerAcl -Name $containerName -Permission Off
        }
        else
        {
            Write-verbose "Container permissions already set to Private (off). Continuing ..."
        }
    }
    else
    {
        Write-verbose "Container does not exist. Creating storage account container now..."
        New-AzureStorageContainer -Name $containerName -Permission Off
    }
}
