Param (
	[Parameter(Mandatory=$true)][string]$RunbookName,
	[Parameter(Mandatory=$true)][string]$ResourceGroupName,
	[Parameter(Mandatory=$true)][string]$AutomationAccountName,
	[Parameter(Mandatory=$true)][string]$PathToRunbook

)

Import-AzureRmAutomationRunbook -Name $RunbookName `
	-Type PowerShell `
	-LogProgress $true `
	-LogVerbose $true `
	-ResourceGroupName $ResourceGroupName `
	-AutomationAccountName $AutomationAccountName `
	-Path $PathToRunbook `
	-Published `
	-Force

#Schedule
$scheduleName = "RotateSASDaily"

Remove-AzureRmAutomationSchedule -Name $scheduleName `
	-ResourceGroupName $ResourceGroupName `
	-AutomationAccountName $AutomationAccountName `
	-Force `
	-ErrorAction SilentlyContinue

New-AzureRmAutomationSchedule -Name $scheduleName `
	-DayInterval 1 `
	-StartTime ([DateTime]::Today).AddDays(1).AddHours(8) `
	-ResourceGroupName $ResourceGroupName `
	-AutomationAccountName $AutomationAccountName

Unregister-AzureRmAutomationScheduledRunbook -Name $RunbookName `
	-ResourceGroupName $ResourceGroupName `
	-AutomationAccountName $AutomationAccountName `
	-ScheduleName $scheduleName `
	-ErrorAction SilentlyContinue

Register-AzureRmAutomationScheduledRunbook -Name $RunbookName `
	-ResourceGroupName $ResourceGroupName `
	-AutomationAccountName $AutomationAccountName `
	-ScheduleName $scheduleName

Start-AzureRmAutomationRunbook -Name $RunbookName -ResourceGroupName $ResourceGroupName -AutomationAccountName $AutomationAccountName -Wait