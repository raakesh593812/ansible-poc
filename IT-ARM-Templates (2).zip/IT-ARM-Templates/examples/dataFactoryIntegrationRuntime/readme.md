Goal: Create Self Hosted Integration Runtime and configure it on azure VMS.

1.Deploy a storage account.(storageaccount.json)
    we need the storage account to upload the dsc script that we are going to use in the vm deployment.
2.deploy a data factory, self hosted integration runtime and a vm with dsc configuration(azuredeploy.json)
    Note: In the azuredeploy.json,the resource "Microsoft.Storage/storageAccounts" is added here because if deployed in complete mode, we do not loose the storage account that is deployed in step 1.