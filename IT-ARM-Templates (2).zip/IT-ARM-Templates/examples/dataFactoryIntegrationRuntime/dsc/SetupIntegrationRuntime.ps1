Configuration SetupIntegrationRuntime
{
    param(
        [Parameter(Mandatory=$true)][string]$IRkey
     )
    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Node localhost {
        Script DownloadIR {
            TestScript = {
                Test-Path "C:\IntegrationRuntime.msi"
            }
            SetScript  = {
                $source = "https://download.microsoft.com/download/E/4/7/E4771905-1079-445B-8BF9-8A1A075D8A10/IntegrationRuntime_3.14.6997.1%20(64-bit).msi"
                $dest = "C:\IntegrationRuntime.msi"
                Invoke-WebRequest $source -OutFile $dest
            }
            GetScript  = {@{Result = "DownloadIR"}}
        }
        Package InstallIR {
            Ensure    = "Present"  
            Path      = "C:\IntegrationRuntime.msi"
            Name      = "Microsoft Integration Runtime"
            ProductId = "1EE651E1-4714-40AF-8A87-B3C905E55D34"
        }
        Script ConfigureIR
        {
            TestScript = { # the TestScript block runs first. If the TestScript block returns $false, the SetScript block will run
                Test-Path -Path HKLM:\SOFTWARE\Microsoft\DataTransfer\DataManagementGateway\ConfigurationManage
            }
            SetScript = {
                $path = Get-Item "HKLM:\Software\Microsoft\DataTransfer\DataManagementGateway\ConfigurationManager"
                $filepath = $path.GetValue('DiacmdPath')
                $params = "-k $using:IRkey"
                Start-Process -FilePath $filepath -ArgumentList $params -Wait -Passthru -NoNewWindow
            }
            GetScript = {
                $result = Test-Path -Path HKLM:\SOFTWARE\Microsoft\DataTransfer\DataManagementGateway\ConfigurationManager
                @{
                    "Downloaded" = $result
                }
            }
            DependsOn  = "[Package]InstallIR"
        }
    }

}