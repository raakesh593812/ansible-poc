# ***** Example Moved *****
This example has been moved to provide a fully functional example of source code, build, and releases to demonstrate the entire flow of source through VSTS to Azure 

The Wiki article describing the example - https://dupont.sharepoint.com/teams/teams_azure_app/howto/Lists/Posts/Post.aspx?ID=35

The IT-WebAppDemonstration information can be found here  - 

Resource group definition is item 209 here - https://agcompany.sharepoint.com/teams/azure_arm_provisioning/Lists/AgCo%20%20Resource%20Groups/AllItems.aspx

The source code repository - https://vs-pioneer.visualstudio.com/infrastructure/CloudEngineering/_git/IT-WebAppDemonstration 
The build definition - https://vs-pioneer.visualstudio.com/infrastructure/CloudEngineering/_apps/hub/ms.vss-ciworkflow.build-ci-hub?_a=edit-build-definition&id=412 
The release definition - https://vs-pioneer.visualstudio.com/infrastructure/CloudEngineering/_apps/hub/ms.vss-releaseManagement-web.cd-workflow-hub?definitionId=26&_a=environments-editor-preview