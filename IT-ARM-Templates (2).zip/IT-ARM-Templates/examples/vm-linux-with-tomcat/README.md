When deploying Linux VM with Tomcat templates:
    1. allow the template to run once to provision storage account and vm. it will fail.
    2. when storage account is provisioned, add tomcat-setup.sh to the storage account (in a blob container labeled "scripts") provisioned by your template. 
    3. re-run the deployment. 

    Alternative instructions:
        1. provision a storage account.
        2. add tomcat-setup.sh to the storage account in a blob container named "scripts"
        3. run template, linking storage account you've provisioned to the template so that it knows not to make another one. 

**If you're having issues getting it to deploy, know that sometimes it requires 2 or 3 deployment attempts to succeed. (I have no idea why.) Each time you deploy, give your deployment a different
    name, and delete all previous deployment instances from the portal so that you're starting fresh. 