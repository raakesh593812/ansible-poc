param(
    [string] $ResourceGroupName,
    [string] $SqlVmName
)

Write-Host "Subscription: $SubscriptionName"
Write-Host "Resource Group: $ResourceGroupName"
Write-Host "================================================================================"

$vm = Get-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $SqlVmName

Write-Host $ResourceGroupName
Write-Host $vm.Name
Write-Host "================================================================================"
$VmName = $vm.Name
$Location = $vm.Location
$ExtName = "VMSetup"
$ServiceName = "MSSQLSERVER";

#NET STOP MSSQLSERVER & NET START MSSQLSERVER /mSQLCMD & SQLCMD -S . -Q "CREATE LOGIN [BUILTIN\administrators] FROM WINDOWS; EXEC master..sp_addsrvrolemember @loginame = N'BUILTIN\administrators', @rolename = N'sysadmin'" & NET STOP MSSQLSERVER & NET START MSSQLSERVER"
$Settings = @{ commandToExecute = "NET STOP $ServiceName & NET START $ServiceName /mSQLCMD & SQLCMD -S . -Q `"CREATE LOGIN [BUILTIN\administrators] FROM WINDOWS; EXEC master..sp_addsrvrolemember @loginame = N'BUILTIN\administrators', @rolename = N'sysadmin'`" & NET STOP $ServiceName & NET START $ServiceName" }
Set-AzureRmVMExtension -ResourceGroupName $ResourceGroupName -VMName $VmName -Publisher 'Microsoft.Compute' -ExtensionType 'CustomScriptExtension' -Name $ExtName -Location $Location -TypeHandlerVersion '1.8' -Settings $Settings
(Get-AzureRmVMExtension -ResourceGroupName $ResourceGroupName -VMName $VmName -Name $ExtName -Status).SubStatuses | % { $_.Code + "`n" + $_.Message.Replace('\n', "`n") }
Remove-AzureRmVMExtension -ResourceGroupName $ResourceGroupName -VMName $VmName -Name $ExtName -Force
