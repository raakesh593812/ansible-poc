﻿param(
    [string] $namePrefix,
    [string] $domainName,
    [string] $adminGroupPrefix
    
)
$VerbosePreference = "Continue"

Function Test-GroupInLocalAdmin($GroupToTest) {
    $AdminGroup = [ADSI]"WinNT://$env:computername/Administrators,group"
    Write-Verbose "Checking $($AdminGroup.Path) for $GroupToTest"
    if (($adminGroup.psbase.Invoke("Members") | % { $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null) }) -contains $GroupToTest) {
        Write-Verbose "$GroupToTest is in Administrators group"
        return $true
    }
    else {
        Write-Verbose "$GroupToTest is not in Administrators group"
        return $false
    }
}

#Add VM Admin Group to local Administrators
if ([string]::IsNullOrEmpty($domainName)) {
    Write-Verbose "Skip AD join"
} else {
    $adminGroupName = "$adminGroupPrefix-$namePrefix"
    if(!(Test-GroupInLocalAdmin -GroupToTest $adminGroupName)) {
        $groupPath = 'WinNT://{0}/{1},group' -f $domainName, $adminGroupName
        & { ([adsi]'WinNT://./Administrators,group').Add($groupPath); }
        ([ADSI]("WinNT://$env:COMPUTERNAME/Administrators,group")).Add(([ADSI]"WinNT://$domainName\$adminGroupName").path)
    }
}

#Install Agents
Write-Verbose "Installing McAfee"
start -wait -FilePath '.\McAfeeAgent-5.0.6.220.exe' -ArgumentList '/silent /install=agent'