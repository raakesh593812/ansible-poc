Configuration SetupHCM
{
	param ($serviceBus, $sharedAccessKeyName, $sharedAccessKeyValue, $hybridConnectionName)
	$connectionString = "Endpoint=sb://$serviceBus.servicebus.windows.net/$hybridConnectionName;SharedAccessKeyName=$sharedAccessKeyName;SharedAccessKey=$sharedAccessKeyValue"

    Import-DscResource -ModuleName PsDesiredStateConfiguration
    Node localhost {
        Script DownloadHCM
        {
            TestScript = {
                Test-Path "C:\HybridConnectionManager.msi"
            }
            SetScript = {
                $source = "http://download.microsoft.com/download/0/E/4/0E48D57B-C563-4877-8ACB-CB740C7C6A78/HybridConnectionManager.msi"
                $dest = "C:\HybridConnectionManager.msi"
                Invoke-WebRequest $source -OutFile $dest
            }
            GetScript = {@{Result = "DownloadHCM"}}
        }

        Package InstallHCM
        {
            Ensure = "Present"  
            Path  = "C:\HybridConnectionManager.msi"
            Name = "Hybrid Connection Manager"
            ProductId = "E882AE21-2DE9-4230-84FC-5BC554856670"
        }
        Script ConfigureHCM
        {
            TestScript = { 
                import-module $env:ProgramW6432'\Microsoft\HybridConnectionManager 0.7\HybridConnectionManager' 
                [bool](Get-HybridConnection).Length
            }
            SetScript = {
                import-module $env:ProgramW6432'\Microsoft\HybridConnectionManager 0.7\HybridConnectionManager' 
                Add-HybridConnection -ConnectionString $using:connectionString
            }
            GetScript = {@{Result = "ConfigureHCM"}}
            DependsOn = "[Package]InstallHCM"
        }
        Service HCMServiceStarted
        {                    
            Name = "HybridConnectionManager"
            StartupType = "Automatic"
            State = "Running"
            DependsOn = "[Script]ConfigureHCM"
        }
    }
}