#!/bin/bash

# writes a date/time stamped message to a file
function log_message {
    message="$1"
    log_file="$2"

    if [ ! -f $log_file ]; then
        touch $log_file
    fi

    log_datetime=`date +%Y%m%d%H%M%S`

    echo "$log_datetime: $message" >> $log_file
}

# checks to see if argument is empty string or only spaces
# returns 1 if empty string or spaces
# returns 0 otherwise
function test_empty_or_spaces {
    var="$1"

    if [[ -z "${var// }" ]]; then
        result=1
    else
        result=0
    fi

    echo $result
}

# checks the distribution we are running on
# returns 1 if the distribution is one we can handle
# returns 0 otherwise
function test_valid_distribution {
    # very crude way of doing business for now
    test -f /usr/bin/yum
    result=$?

    # switch 1s and 0s around 
    (( result = 1 - result ))
    echo $result
}

# check to see if joined to an AD domain
# returns 1 if joined
# returns 0 otherwise
function test_domain_joined {
    results=$(realm list | head -1)

    if [ -z "$results" ]; then
        joined=0
    else
        joined=1
    fi
    echo $joined
}

function join_domain {
    domain_name="$1"
    domain_site="$2"
    domain_controller="$3"
    domain_username="$4"
    domain_password="$5"
    domain_oupath="$6"
    os_name="$7"
    os_version="$8"
    id_mapping="$9"
    vmname_config="${10}"

    max_attempts=3
    attempt=0

    in_domain=$(test_domain_joined)

    while (( in_domain == 0 && attempt < max_attempts )); do
        (( attempt = attempt + 1 ))
        log_message "Domain join attempt number $attempt" $LOG_FILE
        log_message "Restarting dbus service" $LOG_FILE
        service dbus restart
        log_message "Restarting realmd service" $LOG_FILE
        systemctl start realmd.service
        log_message "Executing realm discover $domain_controller" $LOG_FILE
        ( time realm discover $domain_controller --verbose >> $LOG_FILE ) 2>> /var/log/output.time.txt
        log_message "Joining to domain $domain_name via controller $domain_controller" $LOG_FILE
        ( time echo $domain_password | realm join $domain_controller --user=$domain_username --computer-ou=$domain_oupath --os-name="$os_name" $AUTOMATIC_ID_MAPPING --os-version="$os_version" --verbose >> $LOG_FILE 2>&1) 2>> /var/log/output.time.txt

        in_domain=$(test_domain_joined)

        if (( ! in_domain )); then
            sleep 5
        fi
    done

    if (( in_domain )); then
        log_message "Modifying /etc/sssd/sssd.conf" $LOG_FILE
        domain_lower=$(echo $domain_name | tr '[:upper:]' '[:lower:]')
        cp /etc/sssd/sssd.conf /etc/sssd/sssd.conf.orig
        sed -i "s/ad_server\s*=.*/ad_site = $domain_site\nignore_group_members = True\nsubdomain_inherit = ignore_group_members/" /etc/sssd/sssd.conf
        count=$(grep -c "^ad_enabled_domains" /etc/sssd/sssd.conf)
        if (( count == 0 )); then
            sed -i "s/\(ad_domain.*\)$/\1\nad_enabled_domains = $domain_lower/" /etc/sssd/sssd.conf
        fi
        sed -i "s/\(use_fully_qualified_names\s*=\s*\)True.*/\1False/" /etc/sssd/sssd.conf
        authconfig --updateall
    else
        log_message "Unable to join domain" $LOG_FILE
    fi
}


# changes format of user from domain\account
# to account@domain
function format_domain_username {
    domain="$1"
    user="$2"

    domain_upper=$(echo $domain | tr '[:lower:]' '[:upper:]')
    user_upper=$(echo $user | tr '[:lower:]' '[:upper:]')
    regex="^$domain_upper\\\\.+\$"

    if [[ $user_upper =~ $regex ]]; then
        user=$(echo $user | awk 'BEGIN { FS="\\" } {printf "%s@%s", $2, $1}')
    fi

    echo $user
}

function set_hostname {
    VMNAME_CONFIG="$1"
    DOMAIN_NAME="$2"
    count=`hostname | grep -ic $DOMAIN_NAME`
    log_message "Setting hostname to use $VMNAME_CONFIG" $LOG_FILE
    if [ $VMNAME_CONFIG == "FQDN" ]; then
        if (( count == 0 )); then
            SERVER_FQDN=$(echo `hostname`.$DOMAIN_NAME)
            hostname $SERVER_FQDN
        fi 
    fi    
    if [ $VMNAME_CONFIG == "Short" ]; then
        if (( count == 1 )); then
            SERVER_FQDN=$(echo `hostname` | cut -f1 -d".")
            hostname $SERVER_FQDN
        fi
    fi
}

function is_hostname_changed {
    VMNAME_CONFIG="$1"  
    DOMAIN_NAME="$2"
    changed=0
    count=`hostname | grep -ic $DOMAIN_NAME`
    if [ $VMNAME_CONFIG == "Short" ]; then
        if (( count == 1 )); then
            log_message "The VMNAME_CONFIG previous value is FQDN, now it is $VMNAME_CONFIG" $LOG_FILE
            changed=1
        fi
    fi
    if [ $VMNAME_CONFIG == "FQDN" ]; then
        if (( count == 0 )); then
            log_message "The VMNAME_CONFIG previous value is Short, now it is $VMNAME_CONFIG" $LOG_FILE
            changed=1
        fi
    fi
    echo $changed
}

LOG_FILE='/var/log/joindomain.log.'$(date +%Y%m%d)

DOMAIN_NAME="$1"
DOMAIN_CONTROLLER="$2"
DOMAIN_USERNAME="$3"
DOMAIN_PASSWORD="$4"
DOMAIN_OUPATH="$5"
DOMAIN_SITE="$6"
ALLOWED_GROUP="$7"
AUTOMATIC_ID_MAPPING="$8"
VMNAME_CONFIG="$9"

if (( ! $(test_valid_distribution) )); then
    msg="Invalid Linux distribution, exiting."
    log_message $msg
    echo $msg
    exit 1
fi

log_message "Parameters used: DOMAIN_NAME=$1, DOMAIN_CONTROLLER=$2, DOMAIN_OUPATH=$5, DOMAIN_SITE=$6, ALLOWED_GROUP=$7, AUTOMATIC_ID_MAPPING=$8, VMNAME_CONFIG=$9" $LOG_FILE
# make sure each of the arguments has a value and isn't only spaces
for arg in DOMAIN_NAME DOMAIN_CONTROLLER DOMAIN_USERNAME DOMAIN_PASSWORD DOMAIN_OUPATH DOMAIN_SITE AUTOMATIC_ID_MAPPING VMNAME_CONFIG
do
	if (( $(test_empty_or_spaces "${!arg}") )); then
		log_message "No value for $arg" $LOG_FILE
		exit 1
    fi
done

DOMAIN_USERNAME=$(format_domain_username $DOMAIN_NAME $DOMAIN_USERNAME)
SERVER_FQDN=$(echo `hostname`.$DOMAIN_NAME)
AUTOMATIC_ID_MAPPING_UPPER=$(echo $AUTOMATIC_ID_MAPPING | tr '[:lower:]' '[:upper:]')

if [ $AUTOMATIC_ID_MAPPING_UPPER == "FALSE" ]; then
    AUTOMATIC_ID_MAPPING="--automatic-id-mapping=no"
else
    AUTOMATIC_ID_MAPPING=""
fi

log_message "Installing additional software" $LOG_FILE 
programs=( realmd sssd adcli krb5-workstation krb5-libs samba-common-tools oddjob oddjob-mkhomedir sssd-tools ksh )
for i in "${programs[@]}"; do
    log_message "Installing $i" $LOG_FILE 
    yum -y install $i
    if [ $? -ne 0 ]
    then
        log_message "Re-installing $i" $LOG_FILE
        yum -y install $i
        if [ $? -ne 0 ]
        then
            log_message "Failed to install $i on second attempt." $LOG_FILE
            exit 1
        fi
    else
        log_message "$i installed successfully." $LOG_FILE
    fi
done

log_message "Disabling ntpd and enabling Chronyd" $LOG_FILE
systemctl disable ntpd
systemctl enable chronyd
systemctl start chronyd


log_message "Configuring chrony" $LOG_FILE
cp /etc/chrony.conf /etc/chrony.conf.orig
sed -i "s/^\(server [0-9]\.centos\.pool\.ntp\.org.*\)/#\1/" /etc/chrony.conf
sed -i "s/^\(server [0-9]\.rhel\.pool\.ntp\.org.*\)/#\1/" /etc/chrony.conf

ntp_server_line="server $DOMAIN_CONTROLLER iburst"
count=`grep -c "$ntp_server_line" /etc/chrony.conf`
if (( count == 0 )); then
    echo $ntp_server_line | tee -a /etc/chrony.conf
fi

log_message "Updating system clock and starting chronyd" $LOG_FILE
systemctl restart chronyd.service

. /etc/os-release

if (( ! $(test_domain_joined) )); then
    set_hostname "$VMNAME_CONFIG" "$DOMAIN_NAME"
    join_domain "$DOMAIN_NAME" "$DOMAIN_SITE" "$DOMAIN_CONTROLLER" "$DOMAIN_USERNAME" "$DOMAIN_PASSWORD" "$DOMAIN_OUPATH" "$NAME" "$VERSION" "$AUTOMATIC_ID_MAPPING" "$VMNAME_CONFIG"
else
    EXITSTATUS=$(is_hostname_changed $VMNAME_CONFIG $DOMAIN_NAME)
    if (( $EXITSTATUS == 1 )); then
        exit 1
    fi    
fi

if (( $(test_empty_or_spaces "$ALLOWED_GROUP") )); then
    log_message "No admin group specified, exiting." $LOG_FILE
    exit 0
fi

log_message "Permitting $ALLOWED_GROUP to login" $LOG_FILE
realm permit "$ALLOWED_GROUP" --groups --verbose

sudoers_line="%$DOMAIN_NAME\\\\$ALLOWED_GROUP ALL=(ALL) ALL"
count=`grep -Fc "$sudoers_line" /etc/sudoers`
if (( count == 0 )); then
    log_message "Adding $ALLOWED_GROUP to sudoers file" $LOG_FILE
    echo "$sudoers_line" | EDITOR='tee -a' /sbin/visudo
fi

# restart SSHD
log_message "Restarting sshd" $LOG_FILE
systemctl restart sshd.service