#!/bin/bash

# writes a date/time stamped message to a file
function log_message {
    message="$1"
    log_file="$2"

    if [ ! -f $log_file ]; then
        touch $log_file
    fi

    log_datetime=`date +%Y%m%d%H%M%S`

    echo "$log_datetime: $message" >> $log_file
}

ENABLE_AGENTS="$1"
JOIN_DOMAIN="$2"
DOMAIN_NAME="$3"
DOMAIN_CONTROLLER="$4"
DOMAIN_USERNAME="$5"
DOMAIN_PASSWORD="$6"
DOMAIN_OUPATH="$7"
DOMAIN_SITE="$8"
ALLOWED_GROUP="${9}"
AUTOMATIC_ID_MAPPING="${10}"
VMNAME_CONFIG="${11}"

LOG_FILE='/var/log/custom_script_extension.log.'$(date +%Y%m%d)

ENABLE_AGENTS=$(echo $ENABLE_AGENTS | tr '[:lower:]' '[:upper:]')

if [ $ENABLE_AGENTS == "TRUE" ]; then

	# install Flexera agent
    log_message "Installing Flexera agent" $LOG_FILE
	sh LinuxFlexConfig.sh "$DOMAIN_NAME" && rpm --upgrade --oldpackage --verbose managesoft-13.0.1-1.x86_64.rpm

    #install CrowdStrike falcon sensor
    log_message "Installing Falcon sensor for CrowdStrike" $LOG_FILE
    rpm --upgrade --oldpackage --verbose falcon-sensor-5.38.0-10404.el8.x86_64.rpm
    
    #Setting Customer ID Checksum on sensor
    log_message "Setting customer ID checksum" $LOG_FILE
    /opt/CrowdStrike/falconctl -s --cid=4AA0790CB3CE46BB8F710EA8502567CE-AF

    #Starting sensor
    log_message "Starting falcon-sensor" $LOG_FILE
    systemctl start falcon-sensor

fi

JOIN_DOMAIN=$(echo $JOIN_DOMAIN | tr '[:lower:]' '[:upper:]')

if [ $JOIN_DOMAIN == "TRUE" ]; then
    log_message "Joining domain" $LOG_FILE
    sh LinuxJoinDomain.sh "$DOMAIN_NAME" "$DOMAIN_CONTROLLER" "$DOMAIN_USERNAME" "$DOMAIN_PASSWORD" "$DOMAIN_OUPATH" "$DOMAIN_SITE" "$ALLOWED_GROUP" "$AUTOMATIC_ID_MAPPING" "$VMNAME_CONFIG"
fi