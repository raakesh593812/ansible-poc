﻿#!/bin/bash

function create_random_password {
    pwd=$(date | md5sum | cut -c 1-15)

    echo $pwd
}

# returns 1 if the user exists, 0 otherwise
# grepping /etc/passwd instead of using getent or id
# so we don't accidentally test for AD users
function user_exists {
    user=$1

    count=$(grep -c ^$user: /etc/passwd)

    if (( $count )); then
        exists=1
    else
        exists=0
    fi

    echo $exists
}

# returns 1 if the group exists, 0 otherwise
# grepping /etc/group instead of using getent
# so we don't accidentally test for AD groups
function group_exists {
    group=$1

    count=$(grep -c ^$group: /etc/group)

    if (( $count )); then
        exists=1
    else
        exists=0
    fi

    echo $exists
}

# returns 1 if the group has already been
# allowed login privileges, 0 otherwise
function domain_group_login_allowed {
    group=$1

    count=$(realm list | grep  -c "permitted-groups:.*$group")

    if (( count > 0 )); then
        allowed=1
    else
        allowed=0
    fi

    echo $allowed
}

function append_sudoers_entry {
    sudoers_line="$1"
    
    count=`grep -Fc "$sudoers_line" /etc/sudoers`
    if (( count == 0 )); then
        echo "$sudoers_line" | EDITOR='tee -a' /sbin/visudo
    fi
}

DOMAIN_NAME=$1
TPAM_SERVER_ADMIN_GROUP="SA-TPAM-AZ-Server-Admin"

if (( !  $(group_exists "ShrdSysSup") )); then
    groupadd ShrdSysSup
fi

if (( ! $(group_exists "ShrdAppSup") )); then
    groupadd ShrdAppSup
fi

for (( i=1; i<=4; i++ ))
do
    user=ShrdSysSup$i
    if (( ! $(user_exists $user) )); then
        useradd -m -s /bin/bash -d /home/$user -g ShrdSysSup -G wheel $user
        echo $(create_random_password) | passwd $user --stdin
    fi
done

for (( i=1; i<=6; i++ ))
do
    user=ShrdAppSup$i
    if (( ! $(user_exists $user) )); then
        useradd -m -s /bin/bash -d /home/$user -g ShrdAppSup -G wheel $user
        echo $(create_random_password) | passwd $user --stdin
    fi
done

if (( ! $(domain_group_login_allowed $TPAM_SERVER_ADMIN_GROUP) )); then
    realm permit -g $TPAM_SERVER_ADMIN_GROUP
fi

append_sudoers_entry "%${DOMAIN_NAME}\\\\${TPAM_SERVER_ADMIN_GROUP} ALL=(root) NOPASSWD: /bin/grep"
append_sudoers_entry "%${DOMAIN_NAME}\\\\${TPAM_SERVER_ADMIN_GROUP} ALL=(root) NOPASSWD: /usr/bin/passwd"
append_sudoers_entry "%${DOMAIN_NAME}\\\\${TPAM_SERVER_ADMIN_GROUP} ALL=(root) NOPASSWD: /usr/bin/sed"
append_sudoers_entry "%${DOMAIN_NAME}\\\\${TPAM_SERVER_ADMIN_GROUP} ALL=(root) NOPASSWD: /usr/bin/cat"
append_sudoers_entry "Defaults:%${DOMAIN_NAME}\\\\${TPAM_SERVER_ADMIN_GROUP} !requiretty"