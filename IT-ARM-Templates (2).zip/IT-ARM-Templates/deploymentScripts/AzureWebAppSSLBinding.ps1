param (
	[string]$ResourceGroupName,
	[string]$WebAppName,
	[string]$Thumbprint,
	[string]$DnsName
)

New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupName `
    -WebAppName $WebAppName `
    -Thumbprint $Thumbprint `
    -Name $DnsName