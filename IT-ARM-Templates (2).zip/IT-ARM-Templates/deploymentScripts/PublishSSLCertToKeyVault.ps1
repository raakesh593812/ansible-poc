param (
	[string]$KeyVaultName,
	[string]$SecretName,
	[securestring]$PfxBlob
)

$secretContentType = 'application/x-pkcs12'
Set-AzureKeyVaultSecret -VaultName $KeyVaultName -Name $SecretName -SecretValue $PfxBlob -ContentType $secretContentType