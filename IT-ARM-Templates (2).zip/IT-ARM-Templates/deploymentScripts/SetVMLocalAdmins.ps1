param(
    [array][Parameter(Mandatory=$true)] $UserNames,
    [string] $ResourceGroupName
)

Write-Host "Subscription: $SubscriptionName"
Write-Host "Resource Group: $ResourceGroupName"
Write-Host "================================================================================"

foreach ($vm in (Get-AzureRmVM -ResourceGroupName $ResourceGroupName))
{
    $VmName = $vm.Name
    $Location = $vm.Location
    $ExtName = "SetLocalAdmins"

    Write-Host "VM: $VmName"
    Write-Host "--------------------------------------------------------------------------------"

    $Settings = @{ commandToExecute = 'powershell -command "& { @(''' + ($UserNames -join ''',''') + ''') | %{ ([ADSI](''WinNT://'' + $env:COMPUTERNAME + ''/administrators,group'')).Add(''WinNT://'' + $_) } }" & net localgroup administrators' }
    Set-AzureRmVMExtension -ResourceGroupName $ResourceGroupName -VMName $VmName -Publisher 'Microsoft.Compute' -ExtensionType 'CustomScriptExtension' -Name $ExtName -Location $Location -TypeHandlerVersion '1.8' -Settings $Settings
    (Get-AzureRmVMExtension -ResourceGroupName $ResourceGroupName -VMName $VmName -Name $ExtName -Status).SubStatuses | % { $_.Code + "`n" + $_.Message.Replace('\n', "`n") }
    Remove-AzureRmVMExtension -ResourceGroupName $ResourceGroupName -VMName $VmName -Name $ExtName -Force
}
