param (
	[string]$ResourceGroupName,
    [string]$Location,
	[string]$WebAppName,
	[string]$PfxBlob,
	[string]$PfxPassword,
	[string[]]$DnsNames
)


$PropertiesObject = @{
    pfxBlob = $PfxBlob
    password = $PfxPassword
}

$cert = New-AzureRmResource -Name $WebAppName -Location $Location `
                    -PropertyObject $PropertiesObject `
                    -ResourceGroupName $ResourceGroupName `
                    -ResourceType Microsoft.Web/certificates `
                    -ApiVersion 2015-08-01 -Force

Write-Output $cert

foreach($dnsName in $dnsNames) {
    New-AzureRmWebAppSSLBinding -ResourceGroupName $ResourceGroupName `
    -WebAppName $WebAppName `
    -Thumbprint $cert.Properties.thumbprint `
    -Name $dnsName    
}
