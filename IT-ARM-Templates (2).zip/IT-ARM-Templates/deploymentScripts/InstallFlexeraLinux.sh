#!/bin/bash

# writes a date/time stamped message to a file
function log_message {
    message="$1"
    log_file="$2"

    if [ ! -f $log_file ]; then
        touch $log_file
    fi

    log_datetime=`date +%Y%m%d%H%M%S`

    echo "$log_datetime: $message" >> $log_file
}


LOG_FILE='/var/log/Flexeracustom_script_extension.log.'$(date +%Y%m%d)
DOMAIN_NAME=`realm list --name-only`
	
	# install Flexera agent
    log_message "Installing Flexera agent" $LOG_FILE
	sh LinuxFlexConfig.sh "$DOMAIN_NAME" && rpm --upgrade --oldpackage --verbose managesoft-13.0.1-1.x86_64.rpm
    
