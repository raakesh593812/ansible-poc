param(
    [parameter(Mandatory=$true)][string]$DomainName
)

Function Test-InLocalGroup($AccountOrGroup, $GroupToTest) {
    $group = [ADSI]"WinNT://$env:computername/$GroupToTest,group"
    Write-Verbose "Checking $($group.Path) for $AccountOrGroup"
    if (($group.psbase.Invoke("Members") | % { $_.GetType().InvokeMember("Name", 'GetProperty', $null, $_, $null) }) -contains $AccountOrGroup) {
        Write-Verbose "$AccountOrGroup is in Administrators group"
        return $true
    }
    else {
        Write-Verbose "$AccountOrGroup is not in Administrators group"
        return $false
    }
}

function Test-LocalAccountExists {
    param(
        [parameter(Mandatory=$true)][string]$AccountName
    )

    $account = [ADSI]"WinNT://$env:computername/$AccountName,user"

    if ($account.Name -eq $null) { $false } else { $true }
}

function New-LocalAccount {
    param(
        [parameter(Mandatory=$true)][string]$AccountName,
        [parameter(Mandatory=$true)][string]$FullName,
        [parameter(Mandatory=$true)][string]$Description,
        [parameter(Mandatory=$true)][string]$Password
    )

    if (!(Test-LocalAccountExists -AccountName $AccountName)) {
        $computerName = $env:computername
        $account = [ADSI]"WinNT://$computerName/$AccountName,user"

        $Computer = [ADSI]"WinNT://$computerName"; 
        $user = $Computer.Create("User",$AccountName); 
        $user.SetPassword($Password); 
        $user.setinfo(); 
        $user.FullName = $FullName; 
        $user.Description = $Description; 
        $user.setinfo(); 
    }
}

function New-TempPassword {
    $lowerAlpha = "abcdefghijklmnopqrstuvwxyz".ToCharArray()
    $upperAlpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
    $digits = "0123456789".ToCharArray()
    $specialChars = "()~!@#$%^&*-+=|\{}[]:;<>,.?/".ToCharArray()

    for ($i = 0; $i -lt 5; ++$i) {
        $password += ($lowerAlpha | Get-Random)
        $password += ($upperAlpha | Get-Random)
        $password += ($digits | Get-Random)
        $password += ($specialChars | Get-Random)
    }

    $password
}

$tpamFullName = "TPAM"
$tpamDescription = "TPAM Managed Account - Do not delete"
$tpamServerAdminGroup = "SA-TPAM-AZ-Server-Admin"

$computerName = $env:computername
$administratorsGroup = [ADSI]"WinNT://$computerName/Administrators,group";

$tpamAccounts = @(
    "ShrdSysSup1",
    "ShrdSysSup2",
    "ShrdSysSup3",
    "ShrdSysSup4",
    "ShrdAppSup1",
    "ShrdAppSup2",
    "ShrdAppSup3",
    "ShrdAppSup4",
    "ShrdAppSup5",
    "ShrdAppSup6"
)

$tpamAccounts | % { 
    $password = New-TempPassword | ConvertTo-SecureString -AsPlainText -Force
    New-LocalAccount -AccountName $_ -FullName $tpamFullName -Description $tpamDescription -Password $password
     
    if (!(Test-InLocalGroup $_ 'Administrators')) {
        $administratorsGroup.Add("WinNT://$_,user") 
    }
}; 

if (!(Test-InLocalGroup -AccountOrGroup $tpamServerAdminGroup "Administrators")) {
    $groupPath = "WinNT://{0}/{1},group" -f $DomainName, $tpamServerAdminGroup
    & { ([adsi]'WinNT://./Administrators,group').Add($groupPath); }
    ([ADSI]("WinNT://$computerName/Administrators,group")).Add(([ADSI]"WinNT://$DomainName\$tpamServerAdminGroup").path)
}