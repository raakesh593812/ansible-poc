function ConvertTo-HashTable {
  [CmdletBinding()]
  Param(
    [Parameter(Mandatory = $false)]
    $InputObject
  )

  if ($InputObject) {
    # Convert to string prior to converting to hashtable
    $objectString = ConvertTo-Json -InputObject $InputObject -Depth 100

    # Convert string to hashtable and return it
    return ConvertFrom-Json -InputObject $objectString -AsHashtable;
  } else {
    return $null;
  }
}

function Export-NUnitXml {
  <#
  .SYNOPSIS
  Takes results from ARMTTK and exports them as a Pester test results file (NUnitXml format).

  .DESCRIPTION
  Takes results from ARMTTK and exports them as a Pester test results file (NUnit XML schema).
  Because the generated file in NUnit-compatible, it can be consumed and published by most continuous integration tools.

  .PARAMETER TestResults
  Object containing all test results

  .PARAMETER Path
  Path to store results

  .INPUTS
  <none>

  .OUTPUTS
  <none>

  .NOTES
#>
  [CmdletBinding()]
  Param (
    [Parameter(Mandatory, Position = 0)]
    [AllowNull()]
    [PSObject[]]$TestResults,

    [Parameter(Mandatory, Position = 1)]
    [string]$Path
  )

  #Validate
  if (-not (Test-Path $Path)) {
    New-Item -ItemType Directory -Force -Path $path | Out-Null
  }
  if ((Get-Item $Path) -isnot [System.IO.DirectoryInfo]) {
    throw "resultLocation must be a folder, not a file"
  }

  # Setup variables
  $totalNumber = If ($TestResults) { $TestResults.Count -as [string] } Else { '1' }
  $failedNumber = If ($TestResults) { $($TestResults.passed | Where-Object { $_ -eq $false }).count -as [string] } Else { '0' }
  $now = Get-Date
  $formattedDate = Get-Date $now -Format 'yyyy-MM-dd'
  $formattedTime = Get-Date $now -Format 'T'
  $user = $env:USERNAME
  $machineName = $env:COMPUTERNAME
  $cwd = $pwd.Path
  $userDomain = $env:USERDOMAIN
  $currentCulture = (Get-Culture).Name
  $uICulture = (Get-UICulture).Name

  Switch ($failedNumber) {
    0 { $TestResult = 'Success'; $TestSuccess = 'True'; Break }
    Default { $TestResult = 'Failure'; $TestSuccess = 'False' }
  }

  $fileList = $TestResults.File.FullPath | get-unique

  #Create separate XML for each test file
  foreach ($testFile in $fileList) {

    # Get test results that are specific to this file
    $splitTestsBody = [string]::Empty
    $filteredTestResults = $testResults | where-object { $_.File.FullPath -eq $testFile }
    $failedNumber = If ($filteredTestResults) { $($filteredTestResults.passed | Where-Object { $_ -eq $false }).count -as [string] } Else { '0' }
    $totalNumber = If ($filteredTestResults) { $filteredTestResults.Count -as [string] } Else { '1' }
    Switch ($failedNumber) {
      0 { $TestResult = 'Success'; $TestSuccess = 'True'; Break }
      Default { $TestResult = 'Failure'; $TestSuccess = 'False' }
    }

    $directoryName = Split-Path (Split-Path $testFile -Parent) -Leaf
    $fileName = Split-Path $testFile -Leaf

    # generate body of XML
    $header = @"
<?xml version="1.0" encoding="utf-8" standalone="no"?>
  <test-results xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="nunit_schema_2.5.xsd" name="ARMTTK" total="$totalNumber" errors="0" failures="$failedNumber" not-run="0" inconclusive="0" ignored="0" skipped="0" invalid="0" date="$formattedDate" time="$formattedTime">
      <environment user="$User" machine-name="$MachineName" cwd="$Cwd" user-domain="$UserDomain" platform="$Platform" nunit-version="2.5.8.0"  />
      <culture-info current-culture="$CurrentCulture" current-uiculture="$UICulture" />
      <test-suite type="Powershell" name="ARMTTK" executed="True" result="$TestResult" success="$TestSuccess" time="0.0" asserts="0">
      <results>`n
"@

    $footer = @"
          </results>
        </test-suite>
      </test-results>
"@

    $testHeader = @"
  <test-suite type="TestFixture" name="$directoryName\$fileName" executed="True" result="$TestResult" success="$TestSuccess" time="0.0" asserts="0" description="ARMTTK tests for $fileName">
  <results>`n
"@

    $filterBody = [string]::Empty
    #Generate XML for each test result
    foreach ($result in $filteredTestResults) {

      $testCase = [string]::Empty

      if ($result.Passed) {
        $TestCase = @"
  <test-case description="$($result.name) in template file $directoryName\$fileName" name="$($result.name) - $fileName" time="$($result.TimeSpan.ToString())" asserts="0" success="True" result="Success" executed="True">
  </test-case>`n
"@
      } else {
        $stacktraceError = [System.Security.SecurityElement]::Escape($result.Errors.ScriptStackTrace)
        $testCase = @"
  <test-case description="$($result.name) in template file $fileName" name="$($result.name) - $fileName" time="$($result.TimeSpan.ToString())" asserts="0" success="False" result="Failure" executed="True">
  <failure>
      <message><![CDATA[$($result.Errors.Exception)]]> in template file $fileName</message>
      <stack-trace><![CDATA[$stacktraceError]]></stack-trace>
  </failure>
  </test-case>`n
"@
      }
      $filterBody += $TestCase
    }

    $testFooter = @"
</results>
</test-suite>`n
"@
    #Combine strings to make full result
    $testBody = $testHeader + $filterBody + $testFooter
    $splitTestsBody = $splitTestsBody + $testBody

    # Test XML to make sure it is valid
    $nUnitXml = $Header + $splitTestsBody + $Footer

    Try {
      $XmlCheck = [xml]$nUnitXml
      $XmlCheck | Out-Null
    } Catch {
      Throw "There was an problem when attempting to cast the output to XML : $($_.Exception.Message)"
    }

    $hash = Get-FileHash -Path $testFile -Algorithm MD5
    $nUnitXml | Out-File -FilePath "$Path\$($(get-item $testFile).basename)-$($hash.Hash)-armttk.xml" -Encoding utf8 -Force
  }
}

<#
.SYNOPSIS
  Example deployment script to deploy policies to a preferred subscription or management group started with name or filter.

.DESCRIPTION
  Example deployment script to deploy policies to a preferred subscription or management group started with name or filter.

.PARAMETER ModuleName
  Name of the module to install

.EXAMPLE
  Invoke-ModuleInstall -ModuleName "Az"

.INPUTS
  <none>

.OUTPUTS
  <none>

.NOTES
#>
function Invoke-ModuleInstall {
  [CmdletBinding()]
  param (
    [Parameter()]
    [string] $ModuleName
  )

  # If module is imported say that and do nothing
  if (Get-Module | Where-Object { $_.Name -eq $ModuleName }) {
    Write-Output "Module: [$($ModuleName)] is already imported."
  } else {

    # If module is not imported, but available on disk then import
    if (Get-Module -ListAvailable | Where-Object { $_.Name -eq $ModuleName }) {
      Write-Output "Importing module: [$($ModuleName)]..."
      Import-Module $ModuleName
    } else {

      # If module is not imported, not available on disk, but is in online gallery then install and import
      if (Find-Module -Name $ModuleName | Where-Object { $_.Name -eq $ModuleName }) {
        Write-Output "Installing module: [$($ModuleName)]..."
        Install-Module -Name $ModuleName -Force -Scope CurrentUser
        Import-Module $ModuleName
      } else {

        # If module is not imported, not available and not in online gallery then abort
        Write-Output "Module: [$($ModuleName)] not imported, not available and not in online gallery, exiting."
      }
    }
  }
}
