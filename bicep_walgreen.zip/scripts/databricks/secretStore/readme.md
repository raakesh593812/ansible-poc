# Usage

- Download the ps1 file and execute per examples below.
- The person executing this Powershell script must have the contributor role in Key Vault (to grant the access policy to the Databricks Service Principal) and must be a admin in Databricks (to create the secret scope.)
- If you are working in a WBA NSAe environment, you must do a PIM request to activate the necessary roles for contributor access to Key Vault and Databricks.
- The Powershell script will initiate the az login command. Log in with the appropriate user. **T1 account if in production**
- On first run, the Powershell environment may require intallation of the Databricks az cli extension. 
- If running from a PAW you will likely need to run "Set-ExecutionPolicy -Scope CurrentUser Unrestricted" first

# Examples

## Becker Local Dev

./Configure-KeyVault-Backed-Secret-Store.ps1 -vaultName 'kv-mibecke-sandbox' -resourceGroup 'rg-sandbox' -secretScopeName 'etl' -subscriptionID '7a8fb3e5-9699-4869-93b4-c011fb7fc532' -databricksWorkspaceName 'adb-mibecke'

## Dev

./Configure-KeyVault-Backed-Secret-Store.ps1 -vaultName 'dev-martech-kv-03' -resourceGroup 'dev-martech-data-rg-eastus2-01' -secretScopeName 'etl' -subscriptionID '9b6e1295-1d5e-461f-ae1b-3198de739664' -databricksWorkspaceName 'dev-martech-dbw-01'

## Prod

./Configure-KeyVault-Backed-Secret-Store.ps1 -vaultName 'prod-martech-kv-02' -resourceGroup 'prod-martech-data-rg-eastus2-01' -secretScopeName 'etl' -subscriptionID 'd26cc153-8817-4f83-8ddd-2be78bf75b5b' -databricksWorkspaceName 'prod-martech-dbw-01'