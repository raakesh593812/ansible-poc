# If you get a closed connection error, run this line
# [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

param
(
    $vaultName, 
    $resourceGroup,
    $secretScopeName,
    $subscriptionId,
    $databricksWorkspaceName
)    

az login --output none
az account set --subscription $subscriptionId

$dataBricksManagementURI = "https://" + $(az databricks workspace show --resource-group $resourceGroup --name $databricksWorkspaceName --query workspaceUrl -o tsv)
$tokenResponse = az account get-access-token --resource 2ff814a6-3304-4ab8-85cb-cd0e6f879c1d | ConvertFrom-Json 
$token = $tokenResponse.accessToken

Write-Host("Databricks workspace url: " + $dataBricksManagementURI)

$vaultUri = "https://${vaultName}.vault.azure.net/"
$vaultid = "/subscriptions/${subscriptionId}/resourceGroups/${resourceGroup}/providers/Microsoft.KeyVault/vaults/${vaultName}"

#---------------------------------------------------------------------
#> 1) Test connection with a Get against the cluster i.e. cluster list
$params = @{
    Method          = 'GET'
    Headers         = @{
        Authorization = "Bearer $token"
    }
    UseBasicParsing = $true
    #SslProtocol     = 'Tls12'
    uri             = "${dataBricksManagementURI}/api/2.0/clusters/list"
}
# Write-Host($params | ConvertTo-Json)
$r = Invoke-WebRequest @params
# $r.RawContent
Write-Host("Successfully tested connectivity to databricks management api.")

#---------------------------------------------------------------------
<#
HTTP/1.1 200 OK
Server: databricks
#>

# Create secret scope
# https://docs.microsoft.com/en-us/azure/databricks/dev-tools/api/latest/secrets#--create-secret-scope

#---------------------------------------------------------------------
#> 2) Now peform a post to create the secrets scope
$params = @{
    Method          = "Post"
    Headers         = @{
        Authorization = "Bearer $token"
    }
    UseBasicParsing = $true
    #SslProtocol     = 'Tls12'
    uri             = "${DataBricksManagementURI}/api/2.0/secrets/scopes/create"
    ContentType     = "application/json"
    Body            = @{
        "scope"                    = $secretScopeName
        "scope_backend_type"       = "AZURE_KEYVAULT"
        # 'initial_manage_principal' = 'users'
        "backend_azure_keyvault"   = @{
        "resource_id" = $vaultid
        "dns_name"    = $vaultUri
        } 
    } | ConvertTo-Json
}
$r = Invoke-WebRequest @params
# $r.RawContent
Write-Host("Secret scope " + $secretScopeName + " created.")


#---------------------------------------------------------------------
<#
HTTP/1.1 200 OK
Server: databricks
Date: Thu, 08 Apr 2021 21:56:44 GMT
#>
#---------------------------------------------------------------------
#> 3) Now read back the created secrets scopes
$params = @{
    Method          = 'GET'
    Headers         = @{
        Authorization = "Bearer $token"
    }
    UseBasicParsing = $true
    #SslProtocol     = 'Tls12'
    uri             = "${dataBricksManagementURI}/api/2.0/secrets/scopes/list"
}
$r = Invoke-WebRequest @params
# $r.Content 
$r.Content | ConvertFrom-Json | ForEach-Object scopes 
