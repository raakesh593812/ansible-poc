# Databricks Post-Deployment Scripts

In this folder, you'll find a series of scripts that can be used to configure a Databricks workspace post-deployment, that is, after the workspace infrastructure has been created. Included in this folder are two types of scripts:

1. Authentication/Authorization: Scripts used to request access tokens to the Databricks workspace, or obtain the unque databricks workspace deployed (needed for API calls), and
2. Artifact scripts, for creating databricks artifacts like clusters and notebooks.

## API Reference

All of these scripts utilize, to some extent, the API 2.0 interface exposed by Databricks. You can reference that information here: [https://docs.databricks.com/dev-tools/api/latest/index.html]

## A note about these scripts...

These scripts were designed to be used in an Azure DevOps pipeline. You will see instances where thes PowerShell scripts both reference (ex: `$env:MY_VARIABLE`) and set (ex: `Write-Host "##vso[task.setvariable variable=MY_VARIABLE]$somevalue`) new environment variables (which are pipeline variables) for security and re-use. 

## Order of Operations

The Databricks API supports both Personal Access Token (PAT) access, where users can create access tokens for use by the API and/or the Databricks CLI, or you can use AAD authentication to first request an access token and then use that for authentication to the API. All of the scripts in this folder are currently (and should always) use this method.

To start, you need to know thew URL of the databricks workspace you want to connect to. This is unique to each deployment. You can get the URI from the Azure Management API. These are demonstrated in the following scripts:

* **Get-GenericToken.ps1:** Requests an access token to management.core.windows.net to read details about a resource group. Once obtained...
* **Get-WorkspaceURL.ps1:** ... then use this code to obtain the unique workspace URL. This uses the Azure management APIs to return these properties.


Once you have the unique URL, you can start using the Databricks API by calling that URI dirrectly in the base of your calls. Included in this example are:

* **Get-DatabricksAADToken.ps1**: Used to obtain an access token to the databricks workspace. Note that "resource" here is hardcoded to a guid for Databricks resources
* **New-DatabricksNoteook.ps1**: This shows how you can take a source .dbc (Databricks Archive), read in the bytes, and write to a target workspace.
* **New-DatabricksCluster.ps1**: This demonstrates how to create a new cluster, and the bare-bones configuration for a new cluster (nodes, node type, runtime details, etc). More options are possible, but these are outlined in the API reference above.