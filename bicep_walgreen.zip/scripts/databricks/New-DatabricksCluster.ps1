$Url = "https://$env:WORKSPACE_URL/api/2.0/clusters/create"
$Headers = @{
    Authorization = "Bearer $env:SP_DATABRICKS_TOKEN"
   "Content-Type" = "text/plain"
}

$Body = @{
    num_workers = $null
    autoscale = @{
        min_workers = 1
        max_workers = 3
    }
    cluster_name = "test-cluster"
    spark_version = "7.5.x-scala2.12"
    node_type_id = "Standard_DS3_v2"
    driver_node_type_id = "Standard_DS3_v2"
    spark_env_vars = @{
        PYSPARK_PYTHON = "/databricks/python3/bin/python3"
    }
    autotermination_minutes = 30
}

Invoke-RestMethod -Method 'Post' -Uri $url -Headers $Headers -Body ($Body | ConvertTo-JSON)
