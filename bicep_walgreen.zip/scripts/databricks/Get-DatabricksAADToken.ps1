[CmdletBinding()]
param (
  [Parameter()]
  [string] $TenantId = $(Get-AzContext).Tenant.Id,

  [Parameter()]
  [string] $ServicePrincipalClientId,

  [Parameter()]
  [string] $ServicePrincipalClientSecret
)

# check tenant Id is present
if ([string]::IsNullOrEmpty($TenantId)) {
  Write-Error -Message "Failed to obtain tenant Id" -ErrorAction Stop
}

# convert client secret to secure string
#$clientSecret = $ServicePrincipalClientSecret | ConvertTo-SecureString -AsPlainText -Force

# construct headers
# https://docs.microsoft.com/en-us/azure/databricks/dev-tools/api/latest/aad/service-prin-aad-token#--get-an-azure-active-directory-access-token
$headers = @{
  "Content-Type" = "application/x-www-form-urlencoded"
}

$url = 'https://login.microsoftonline.com/{0}/oauth2/token' -f @(
  $TenantId
)

# construct payload
$body = @{
  grant_type    = "client_credentials"
  client_id     = $ServicePrincipalClientId
  client_secret = $ServicePrincipalClientSecret
  resource      = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"
}

$result = Invoke-RestMethod -Method POST -Uri $url -Headers $Headers -Body $body

Write-Output "##vso[task.setvariable variable=SP_DATABRICKS_TOKEN]$($result.access_Token)"
