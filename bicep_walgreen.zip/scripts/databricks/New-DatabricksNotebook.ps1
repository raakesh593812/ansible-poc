$Url = "https://$env:WORKSPACE_URL/api/2.0/workspace/import"
$Headers = @{
  Authorization = "Bearer $env:SP_DATABRICKS_TOKEN"
}

$repository_name = "_databricks-artifacts"

$notebooks = Get-ChildItem -Path "$(System.DefaultWorkingDirectory)/$repository_name/notebooks" | Where-Object { $_.Extension -eq ".dbc" }

ForEach ($n in $notebooks) {
  $fileName = $n.Name
  $fileBytes = Get-Content $n.FullName -AsByteStream
  $fileBytesBase64 = [Convert]::ToBase64String($filebytes)

  $Body = @{
    path         = "/Shared/$fileName"
    language     = "PYTHON"
    cluster_name = "test-cluster"
    format       = "DBC"
    content      = $fileBytesBase64
  }
  Write-Output "Importing $fileName..."
  Invoke-RestMethod -Method 'Post' -Uri $url -Headers $Headers -Body ($Body | ConvertTo-JSON)

}
