<#
  .SYNOPSIS
  Get a Token to work against Azure ARM API

  .DESCRIPTION
  Get a Token to work against Azure ARM API.

  .EXAMPLE
  Get-AzARMToken
#>
function Get-AzARMToken {
    Write-Information -MessageData "Obtaining authentication metadata from local PowerShell session"

    $currentAzureContext = Get-AzContext
    if ($null -eq $currentAzureContext.Subscription.TenantId) {
        Write-Error "No Azure context found. Use 'Connect-AzAccount' to create a context or 'Set-AzContext' to select subscription" -ErrorAction Stop
    }
    $azureRmProfile = [Microsoft.Azure.Commands.Common.Authentication.Abstractions.AzureRmProfileProvider]::Instance.Profile
    $profileClient = [Microsoft.Azure.Commands.ResourceManager.Common.RMProfileClient]::new($azureRmProfile)
    $token = $profileClient.AcquireAccessToken($currentAzureContext.Subscription.TenantId)

    Write-Information -MessageData "Fetched access token with expiration at '$($token.ExpiresOn)'"

    [PSCustomObject]@{
        AccessToken = $token.AccessToken
        ExpiresOn   = $token.ExpiresOn
    }
}

<#
  .SYNOPSIS
  Invokes a Rest call to azure and adds the token to header parameter

  .DESCRIPTION
  Invokes a Rest call to azure and adds the token to header parameter

  .PARAMETER Method
  The method of the rest call

  .PARAMETER Uri
  The uri of the rest call

  .PARAMETER Body
  The body of the rest call as a json string

  .EXAMPLE
  Invoke-AzARMRestMethod -Body $body -Method 'Put' -Uri $uri -Headers $header

  .NOTES
  The function returns a PSCustomObject with the keys InvokeResult
#>
function Invoke-AzARMRestMethod {
    [CmdLetBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Method,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $Uri,

        [Parameter()]
        [ValidateNotNull()]
        [string] $Body
    )

    $token = Get-AzARMToken

    $irmArgs = @{
        Headers         = @{
            Authorization = 'Bearer {0}' -f $token.AccessToken
        }
        ErrorAction     = 'Continue'
        Method          = $Method
        UseBasicParsing = $true
        Uri             = $Uri
    }

    if ($PSBoundParameters.ContainsKey('Body')) {
        [void] $irmArgs.Add('ContentType', 'application/json')
        [void] $irmArgs.Add('Body', $Body)
    }

    try {
        Write-Information -MessageData "Sending HTTP $($irmArgs.Method.ToUpper()) request to $($irmArgs.Uri)"
        $invokeResult = Invoke-RestMethod @irmArgs
    }
    catch {
        $errorMessage = $_.ErrorDetails.Message
        Write-Error -ErrorRecord $_ -ErrorAction Continue
    }

    [PSCustomObject]@{
        InvokeResult  = $invokeResult
        StatusMessage = $errorMessage
    }
}

function Get-AzDataBricksAADToken {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $false)]
        [string] $TenantId = $(Get-AzContext).Tenant.Id,

        [Parameter()]
        [string] $ServicePrincipalClientId,

        [Parameter()]
        [string] $ServicePrincipalClientSecret
    )

    $headers = @{
        "Content-Type" = "application/x-www-form-urlencoded"
    }

    $url = 'https://login.microsoftonline.com/{0}/oauth2/token' -f @(
        $TenantId
    )

    # construct payload
    $body = @{
        grant_type    = "client_credentials"
        client_id     = $ServicePrincipalClientId
        client_secret = $ServicePrincipalClientSecret
        resource      = "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"
    }

    $result = Invoke-RestMethod -Method 'POST' -Uri $url -Headers $Headers -Body $body

    [PSCustomObject]@{
        AccessToken = $result.access_token
    }
}

<#
  .SYNOPSIS
  Gets the workspace Url for Azure Databricks

  .DESCRIPTION
  Gets the workspace Url for Azure Databricks

  .PARAMETER SubscriptionId
  The SubscriptionId where the Databricks is located in

  .PARAMETER ResourceGroupName
  The ResourceGroupName where the Databricks is located in

  .PARAMETER DatabricksName
  The name of the Databricks resource

  .EXAMPLE
  Get-AzDatabricksWorkspaceUrl -SubscriptionId <subId> -ResourceGroupName <rgName> -DatabricksName <adbName>

  .NOTES
#>
function Get-AzDatabricksWorkspaceUrl {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string] $SubscriptionId,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $ResourceGroupName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DataBricksName
    )

    Write-Debug -Message "Processing HTTP GET request to '*/Microsoft.Databricks/workspaces/*' with the following information: $($MyInvocation.BoundParameters | ConvertTo-Json)" -Debug

    $url = 'https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Databricks/workspaces/{2}?api-version=2018-04-01' -f @(
        $SubscriptionId,
        $ResourceGroupName,
        $DataBricksName
    )

    Invoke-AzARMRestMethod -Method GET -Uri $url
}

<#
  .SYNOPSIS
  Create or remove secret scope for Databricks.

  .DESCRIPTION
  Create or remove secret scope for Databricks.

  .PARAMETER WorkspaceUrl
  The url of the Databricks workspace

  .PARAMETER SecretScopeName
  The name of the Databricks secret scope.

  .PARAMETER SubscriptionId
  The SubscriptionId where the Databricks is located in

  .PARAMETER DataBricksResourceGroupName
  The ResourceGroupName where the Databricks is located in

  .PARAMETER DatabricksName
  The name of the Databricks resource

  .PARAMETER DataBricksResourceGroupName
  The ResourceGroupName where the Databricks is located in

  .PARAMETER KeyvaultResourceGroupName
  Optional. The ResourceGroupName of the keyvault for keyvault backed secret only

  .PARAMETER KeyVaultName
  Optional. The Name of the key vault for keyvault backed secret only

  .PARAMETER Operation
  Switch to either create or delete a secret scope from databricks

  .EXAMPLE
  $secretScopeArgs = @{
      WorkspaceUrl                = 'someurl'
      SecretScopeName             = 'demo'
      Subscription                = '1111-2222-33333-blah'
      DataBricksResourceGroupName = 'eotechpoc-rg'
      DataBricksName              = 'testdatabrickswp'
      Operation                   = 'create'
  }
  Invoke-AzDatabricksSecretScope @secretScopeArgs
#>
function Invoke-AzDatabricksSecretScope {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string] $WorkspaceUrl,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $SecretScopeName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $SubscriptionId,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DataBricksResourceGroupName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $DataBricksName,

        [Parameter(Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
        [string] $KeyVaultResourceGroupName,

        [Parameter(Mandatory = $false)]
        [ValidateNotNullOrEmpty()]
        [string] $KeyVaultName,

        [Parameter(Mandatory = $false)]
        [ValidateSet('create', 'delete')]
        [string] $Operation = "create"
    )

    Write-Debug -Message "Processing HTTP POST request to '*/api/2.0/secrets/scopes/*' with the following information: $($MyInvocation.BoundParameters | ConvertTo-Json)" -Debug

    $url = 'https://{0}/api/2.0/secrets/scopes/{1}' -f @(
        $WorkspaceUrl,
        $Operation
    )

    $resourceId = $(Get-AzDatabricksWorkspaceUrl -SubscriptionId $SubscriptionId -ResourceGroupName $DataBricksResourceGroupName -DataBricksName $DataBricksName).InvokeResult.Id

    # construct the header
    $header = @{
        'Authorization'                            = 'Bearer {0}' -f $(Get-AzDataBricksAADToken).AccessToken
        'Content-Type'                             = 'application/json'
        'X-Databricks-Azure-SP-Management-Token'   = $(Get-AzARMToken).AccessToken
        'X-Databricks-Azure-Workspace-Resource-Id' = "$resourceId"
    }

    # construct payload
    # https://docs.microsoft.com/en-us/azure/databricks/dev-tools/api/latest/secrets#create-an-azure-key-vault-backed-scope
    if ($KeyVaultName -and $KeyVaultResourceGroupName) {
        $body = @"
        {
            "scope": "$SecretScopeName",
            "scope_backend_type": "AZURE_KEYVAULT",
            "backend_azure_keyvault":
            {
                "resource_id": "/subscriptions/$($SubscriptionId)/resourceGroups/$($KeyVaultResourceGroupName)/providers/Microsoft.KeyVault/vaults/$($KeyVaultName)",
                "dns_name": "https://$($KeyVaultName).vault.azure.net/"
            }
        }
"@
    }
    else {
        $body = @"
        {
            "scope": "$SecretScopeName"
        }
"@
    }

    Invoke-RestMethod -Method POST -Uri $url -Body $body -Header $header
}

function Invoke-AzDataBricksKeyVaultSecret {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $KeyVaultName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string] $KeyVaultSecretName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [secureString] $KeyVaultSecretValue,

        [Parameter(Mandatory = $false)]
        [ValidateSet('create', 'delete')]
        [string] $Operation = "create"
    )

    Write-Debug -Message "Processing HTTP PUT/DELETE request to '*/Microsoft.KeyVault/vaults/*' with the following information: $($MyInvocation.BoundParameters | ConvertTo-Json)" -Debug

    if ($Operation -eq "create") {

        $url = 'https://{0}.vault.azure.net/secrets/{1}?api-version=7.2' -f @(
            $KeyVaultName,
            $KeyVaultSecretName
        )

        $body = @"
        {
            "value": "$KeyVaultSecretValue"
        }
"@

        Invoke-AzARMRestMethod -Method PUT -Uri $url -Body $body

    }
    else {

        $url = 'https://{0}.vault.azure.net/secrets/{1}?api-version=7.2' -f @(
            $KeyVaultName,
            $KeyVaultSecretName
        )

        Invoke-AzARMRestMethod -Method PUT -Uri $url
    }


    # grant databricks keyvault access policy - done via arm template

    #TODO:
    # Get databricks secret scope process
    #   - check for existing secret name?
    #   - create one if does not exist?
}

Export-ModuleMember -Function *-Az*
