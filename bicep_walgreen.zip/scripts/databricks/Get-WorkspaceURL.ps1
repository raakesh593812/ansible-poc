[CmdletBinding()]
param (
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $ResourceGroupName,

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string] $DatabricksName
)

Write-Output "Obtaining Databricks workspace Url"

$request = @{
    ResourceGroupName = $ResourceGroupName
    Name = $DatabricksName
    ResourceProviderName = 'Microsoft.Databricks'
    ResourceType = 'workspaces'
    ApiVersion = '2018-04-01'
}

$result = Invoke-AzRestMethod -method get @request

$workspaceURL = ($result.Content | ConvertFrom-Json).properties.workspaceUrl

Write-Output "##vso[task.setvariable variable=WORKSPACE_URL]$workspaceURL"
