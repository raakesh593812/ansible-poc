[CmdletBinding()]
param (
    [Parameter()]
    [string] $TenantId = $(Get-AzContext).Tenant.Id,

    [Parameter()]
    [string] $ServicePrincipalClientId,

    [Parameter()]
    [string] $ServicePrincipalClientSecret
)

# check tenant Id is present
if ([string]::IsNullOrEmpty($TenantId)) {
    Write-Error -Message "Failed to obtain tenant Id" -ErrorAction Stop
}

$url = "https://login.microsoftonline.com/$($TenantId)/oauth2/token"
$Headers = @{
    "Content-Type" = "application/x-www-form-urlencoded"
}

$body = @{
    grant_type    = "client_credentials"
    client_id     = $ServicePrincipalClientId
    client_secret = $ServicePrincipalClientSecret
    resource      = "https://management.core.windows.net/"
}

$result = Invoke-RestMethod -Method 'Post' -Uri $url -Headers $Headers -Body $body

Write-Output "##vso[task.setvariable variable=SP_GENERIC_TOKEN]$($result.access_token)"
