IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Date')
    CREATE TABLE [dbo].[Date]
	(
		[DateID] int NOT NULL,
		[Date] datetime NULL,
		[DateBKey] char(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DayOfMonth] varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DaySuffix] varchar(4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DayName] varchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DayOfWeek] char(1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DayOfWeekInMonth] varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DayOfWeekInYear] varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DayOfQuarter] varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DayOfYear] varchar(3) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[WeekOfMonth] varchar(1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[WeekOfQuarter] varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[WeekOfYear] varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Month] varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[MonthName] varchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[MonthOfQuarter] varchar(2) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Quarter] char(1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[QuarterName] varchar(9) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Year] char(4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[YearName] char(7) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[MonthYear] char(10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[MMYYYY] char(6) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[FirstDayOfMonth] date NULL,
		[LastDayOfMonth] date NULL,
		[FirstDayOfQuarter] date NULL,
		[LastDayOfQuarter] date NULL,
		[FirstDayOfYear] date NULL,
		[LastDayOfYear] date NULL,
		[IsHolidayUSA] bit NULL,
		[IsWeekday] bit NULL,
		[HolidayUSA] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
	)
	WITH
	(
		DISTRIBUTION = ROUND_ROBIN,
		CLUSTERED COLUMNSTORE INDEX
	);



IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Geography')
    CREATE TABLE [dbo].[Geography]
	(
		[GeographyID] int NOT NULL,
		[ZipCodeBKey] varchar(10) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[County] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[City] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[State] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[Country] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[ZipCode] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
	)
	WITH
	(
		DISTRIBUTION = ROUND_ROBIN,
		CLUSTERED COLUMNSTORE INDEX
	);



IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='HackneyLicense')
    CREATE TABLE [dbo].[HackneyLicense]
	(
		[HackneyLicenseID] int NOT NULL,
		[HackneyLicenseBKey] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[HackneyLicenseCode] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
	)
	WITH
	(
		DISTRIBUTION = ROUND_ROBIN,
		CLUSTERED COLUMNSTORE INDEX
	);



IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Medallion')
    CREATE TABLE [dbo].[Medallion]
	(
		[MedallionID] int NOT NULL,
		[MedallionBKey] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[MedallionCode] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
	)
	WITH
	(
		DISTRIBUTION = ROUND_ROBIN,
		CLUSTERED COLUMNSTORE INDEX
	);



IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Time')
    CREATE TABLE [dbo].[Time]
	(
		[TimeID] int NOT NULL,
		[TimeBKey] varchar(8) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[HourNumber] tinyint NOT NULL,
		[MinuteNumber] tinyint NOT NULL,
		[SecondNumber] tinyint NOT NULL,
		[TimeInSecond] int NOT NULL,
		[HourlyBucket] varchar(15) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
		[DayTimeBucketGroupKey] int NOT NULL,
		[DayTimeBucket] varchar(100) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL
	)
	WITH
	(
		DISTRIBUTION = ROUND_ROBIN,
		CLUSTERED COLUMNSTORE INDEX
	);



IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Trip')
    CREATE TABLE [dbo].[Trip]
	(
		[DateID] int NOT NULL,
		[MedallionID] int NOT NULL,
		[HackneyLicenseID] int NOT NULL,
		[PickupTimeID] int NOT NULL,
		[DropoffTimeID] int NOT NULL,
		[PickupGeographyID] int NULL,
		[DropoffGeographyID] int NULL,
		[PickupLatitude] float NULL,
		[PickupLongitude] float NULL,
		[PickupLatLong] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[DropoffLatitude] float NULL,
		[DropoffLongitude] float NULL,
		[DropoffLatLong] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[PassengerCount] int NULL,
		[TripDurationSeconds] int NULL,
		[TripDistanceMiles] float NULL,
		[PaymentType] varchar(50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
		[FareAmount] money NULL,
		[SurchargeAmount] money NULL,
		[TaxAmount] money NULL,
		[TipAmount] money NULL,
		[TollsAmount] money NULL,
		[TotalAmount] money NULL
	)
	WITH
	(
		DISTRIBUTION = ROUND_ROBIN,
		CLUSTERED COLUMNSTORE INDEX
	);



IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Weather')
    CREATE TABLE [dbo].[Weather]
	(
		[DateID] int NOT NULL,
		[GeographyID] int NOT NULL,
		[PrecipitationInches] float NOT NULL,
		[AvgTemperatureFahrenheit] float NOT NULL
	)
	WITH
	(
		DISTRIBUTION = ROUND_ROBIN,
		CLUSTERED COLUMNSTORE INDEX
	);


/****** Set DB permissions ******/

-- CREATE USER [user@youraad.com] FROM EXTERNAL PROVIDER;
-- GO
-- EXEC sp_addrolemember 'db_datareader', 'user@youraad.com'; 
-- GO

-- IF EXISTS (SELECT * FROM sys.database_principals WHERE name = 'ADF_NAME')
-- CREATE USER [ADF_NAME] FROM EXTERNAL PROVIDER;
-- GO
-- EXEC sp_addrolemember 'db_datareader', 'ADF_NAME'; 
-- EXEC sp_addrolemember 'db_datawriter', 'ADF_NAME'; 
-- EXEC sp_addrolemember 'db_ddladmin', 'ADF_NAME'; 
-- GO

-- /****** Confirm database roles ******/
-- SELECT DP1.name AS DatabaseRoleName,   
--    isnull (DP2.name, 'No members') AS DatabaseUserName   
--  FROM sys.database_role_members AS DRM  
--  RIGHT OUTER JOIN sys.database_principals AS DP1  
--    ON DRM.role_principal_id = DP1.principal_id  
--  LEFT OUTER JOIN sys.database_principals AS DP2  
--    ON DRM.member_principal_id = DP2.principal_id  
-- WHERE DP1.type = 'R'
-- ORDER BY DP1.name;