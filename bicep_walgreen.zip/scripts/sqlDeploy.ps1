param
(
  [String] [Parameter(Mandatory = $true)] $ServerName,
  [String] [Parameter(Mandatory = $true)] $DatabaseName,
  [String] [Parameter(Mandatory = $true)] $SqlFile
)


$response = Invoke-WebRequest -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://database.windows.net/' -Method GET -Headers @{Metadata = "true" } -UseBasicParsing
Write-Output "calling metadata service"
$content = $response.Content | ConvertFrom-Json
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Data Source = $ServerName; Initial Catalog = $DatabaseName"
$SqlConnection.AccessToken = $content.access_token
$SqlConnection.Open()
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = Get-Content $SqlFile
$SqlCmd.Connection = $SqlConnection
$SqlCmd.ExecuteNonQuery()
$SqlConnection.Close()
