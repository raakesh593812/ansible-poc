# Import all modules for local development

$rootPath = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent

$modulePath = Join-Path "$rootPath" -ChildPath '' -AdditionalChildPath @('Invoke-ARMDeployment.ps1')
. $modulePath
