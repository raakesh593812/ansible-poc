<#
.SYNOPSIS
Run a template deployment.

.DESCRIPTION
Run a template deployment.
Works on a resource group, subscription

.PARAMETER TemplateFilePath
Mandatory. The path to template file to be deployed.

.PARAMETER TemplateParamObject
Mandatory. template parameter object form pipeline.

.PARAMETER Location
Mandatory. Location to test in. E.g. WestEurope

.PARAMETER ResourceGroupName
Optional. Name of the resource group to deploy into. Mandatory if deploying into a resource group (resource group level)

.PARAMETER ParameterFilePath
Optional. Path to the parameter file from root.

.EXAMPLE
New-TemplateDeployment -templateFilePath "$(Build.Repository.LocalPath)" -templateParamObject <hashtable> -location 'WestEurope' -resourceGroupName 'aLegendaryRg'

#>
function New-TemplateDeployment {

  [CmdletBinding(SupportsShouldProcess)]
  param (
    [Parameter(Mandatory)]
    [string] $Environment,

    [Parameter(Mandatory)]
    [string] $TemplateFilePath,

    [Parameter(Mandatory = $false)]
    [hashtable] $TemplateParamObject,

    [Parameter(Mandatory = $false)]
    [string] $TemplateParamFile,

    [Parameter(Mandatory)]
    [string] $Location,

    [Parameter(Mandatory = $false)]
    [string] $ResourceGroupName
  )

  begin {
    Write-Debug ("{0} entered" -f $MyInvocation.MyCommand)
  }

  process {
    # Switch to Continue" so multiple errors can be formatted and output
    $ErrorActionPreference = 'Continue'

    # Print current subscription context
    Get-AzContext

    $DeploymentInputs = @{}

    Foreach ($key in $templateParamObject.Keys) {
      $DeploymentInputs += @{
        $key = $templateParamObject.Item($key)
      }
    }

    if ($TemplateParamFile) {
      Write-Verbose "Detected a parameter file as part of your deployment." -Verbose
      if (Test-Path $TemplateParamFile) {
        Write-Output "$TemplateParamFile"
        $DeploymentInputs += @{
          TemplateParameterFile = $TemplateParamFile
        }
      }
    }

    # Inject appropriate environment tag
    if ($Environment -ne 'prod') {
      $envType = 'Non-Production'
    } else {
      $envType = 'Production'
    }

    $tags = @{
      CostCenter     = 'Marketing Technology'
      LegalSubEntity = 'Walgreen Co'
      Sensitivity    = 'Non-Sensitive'
      SubDivision    = 'Digital Engineering'
      Department     = 'Digital Engineering'
      EnvType        = $envType
      SenType        = 'Not-Applicable'
    }

    Write-Verbose "Got path: $templateFilePath" -Verbose
    $DeploymentInputs += @{
      TemplateFile = $templateFilePath
      Verbose      = $true
      ErrorAction  = 'Stop'
    }

    Write-Verbose ($DeploymentInputs | Format-Table | Out-String) -Verbose

    Write-Verbose ($tags | Format-Table | Out-String) -Verbose

    $deploymentSchema = (ConvertFrom-Json (Get-Content -Raw -Path $templateFilePath)).'$schema'
    switch -regex ($deploymentSchema) {
      '\/deploymentTemplate.json#$' {
        if (-not (Get-AzResourceGroup -Name $resourceGroupName -ErrorAction 'SilentlyContinue')) {

          Write-Verbose "Resource group [$resourceGroupName] does not exist. Creating..." -Verbose

          if ($PSCmdlet.ShouldProcess("Resource group [$resourceGroupName] in location [$location]", "Create")) {
            New-AzResourceGroup -Name $resourceGroupName -Location $location -Tags $tags
          }

          Write-Verbose "Resource group [$resourceGroupName] created." -Verbose
        }

        if ($PSCmdlet.ShouldProcess("Resource group level deployment", "Create")) {
          $result = New-AzResourceGroupDeployment @DeploymentInputs -ResourceGroupName $resourceGroupName -ErrorVariable ErrorMessages
        }
      }
      '\/subscriptionDeploymentTemplate.json#$' {
        if ($PSCmdlet.ShouldProcess("Subscription level deployment", "Create")) {
          $result = New-AzSubscriptionDeployment @DeploymentInputs -location $location -ErrorVariable ErrorMessages
        }
      }
      default {
        throw "[$deploymentSchema] is a non-supported ARM template schema"
      }
    }

    # Display error messages from Azure
    if ($ErrorMessages) {
      Write-Output '', 'Template deployment returned the following errors:', @(@($ErrorMessages) | ForEach-Object { $_.Exception.Message.TrimEnd("`r`n") }) -ErrorAction Stop
    } else {
      if ($result.Outputs) {
        foreach ($outputKey in $Deployment.Outputs.Keys) {
          Write-Verbose ("Set [{0}] deployment output as pipeline environment variable with value: [{1}]" -f $outputKey, $result.Outputs[$outputKey].Value) -Verbose
          Write-Output ("##vso[task.setvariable variable={0};isOutput=true]{1}" -f $outputKey, $result.Outputs[$outputKey].Value)
        }
      }

      Write-Verbose "Deployment successful" -Verbose
    }
  }

  end {
    Write-Debug ("{0} exited" -f $MyInvocation.MyCommand)
  }
}
