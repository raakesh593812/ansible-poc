param
(
    [parameter(Mandatory = $true)] [String] $ResourceGroupName,
    [parameter(Mandatory = $true)] [String] $DataFactoryName,
    [parameter(Mandatory = $true)] [Bool] $Predeployment
)

Write-Output "Getting triggers"
$triggersADF = Get-AzDataFactoryV2Trigger -DataFactoryName $DataFactoryName -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue

if ($null -eq $triggersADF) {
    Write-Output "ADF resource - $($DataFactoryName) does not exist."
}
else {
    Write-Output "processing triggers"
    if ($Predeployment -eq $true) {

        $triggersADF | ForEach-Object {

            if ($_.RuntimeState -ne 'Stopped') {
                Stop-AzDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DataFactoryName -Name $_.name -Force
            }
        }
    }
    else {
        Write-Output $_.RuntimeState
        $triggersADF | ForEach-Object { Start-AzDataFactoryV2Trigger -ResourceGroupName $ResourceGroupName -DataFactoryName $DataFactoryName -Name $_.name -Force }
    }
}
