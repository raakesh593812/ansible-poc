# Martech Reference Design

This reference design implements a hub-and-spoke networking model with all data plane operations happening within VNets through the use of Private Link. This design establishes a clear network perimeter and includes centralized control of all ingress and egress traffic by way of Azure Firewall deployed in the hub VNet. Many aspects of this design are enforced via Azure Policy to ensure a secure baseline is maintained.

![network_diagram.png](./images/diagram-network.png =1000x700)

## DevOps Principles

- [Cultural Manifesto](/docs/devops/CulturalManifesto.md)
- [Definition of Done](/docs/devops/DefinitionOfDone.md)
- [Definition of Ready](/docs/devops/DefinitionOfReady.md)
- [Branching Strategy](/docs/devops/GettingStarted.md#branching-strategy)
- [Design Principles](/docs/devops/DesignPrinciples.md)
- [Githooks](/docs/devops/GitHooks.md)

## Deployment

To get started working on this repository, see the [Getting Started](./docs/GettingStarted.md) guide.

This reference environment includes two main areas that are deployed in the target subscription.

* [Azure Infrastructure](deployments/readme.md) - Represents the solution design.
* [Azure Monitoring](monitoring/readme.md) - Contains information about what's being monitored.

Navigate to each link before for instructions on how these assets are be deployed.