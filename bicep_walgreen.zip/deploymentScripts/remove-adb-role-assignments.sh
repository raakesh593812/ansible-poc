#!/bin/bash

# list all role assignment ids
az role assignment list --scope '/subscriptions/d26cc153-8817-4f83-8ddd-2be78bf75b5b/resourceGroups/prod-martech-data-rg-eastus2-01/providers/Microsoft.Databricks/workspaces/prod-martech-dbw-01'
# az role assignment list --scope '/subscriptions/d26cc153-8817-4f83-8ddd-2be78bf75b5b/resourceGroups/prod-martech-data-rg-eastus2-01/providers/Microsoft.Databricks/workspaces/prod-martech-dbw-02'
az role assignment list --scope '/subscriptions/d26cc153-8817-4f83-8ddd-2be78bf75b5b/resourceGroups/prod-martech-data-rg-eastus2-01/providers/Microsoft.Storage/storageAccounts/prodmartechrstdsa01'

# remove role assignments
az role assignment delete --ids /subscriptions/d26cc153-8817-4f83-8ddd-2be78bf75b5b/resourceGroups/prod-martech-data-rg-eastus2-01/providers/Microsoft.Databricks/workspaces/prod-martech-dbw-01/providers/Microsoft.Authorization/roleAssignments/121b0aaa-8e18-40ba-8777-d03265e43505

az role assignment delete --ids /subscriptions/d26cc153-8817-4f83-8ddd-2be78bf75b5b/resourceGroups/prod-martech-data-rg-eastus2-01/providers/Microsoft.Storage/storageAccounts/prodmartechrstdsa01/providers/Microsoft.Authorization/roleAssignments/eafbe289-e787-4919-9e0a-76cdbeefa9a6
