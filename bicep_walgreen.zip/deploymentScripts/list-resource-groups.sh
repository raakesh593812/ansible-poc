#!/bin/bash
az group list