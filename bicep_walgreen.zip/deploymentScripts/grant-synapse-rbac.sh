#!/bin/bash
environment=${environment:-dev}

while [ $# -gt 0 ]; do

   if [[ $1 == *"--"* ]]; then
        param="${1/--/}"
        declare $param="$2"
        # echo $1 $2 // Optional to see the parameter:value result
   fi

  shift
done

if [ $environment = 'prod' ]; then
    subscription=d26cc153-8817-4f83-8ddd-2be78bf75b5b
    assignee=77546650-3fc7-4600-bb68-c3595949e48a
elif [ $environment = 'dev' ]; then
    subscription=9b6e1295-1d5e-461f-ae1b-3198de739664
    assignee=b625a3ce-1163-4360-8d2e-9e023d11f38d
elif [ $environment = 'uat' ]; then
    subscription=9b6e1295-1d5e-461f-ae1b-3198de739664
    assignee=be66ad78-95fb-4d03-8363-359e7cb7a714    
fi

identityDisplayName='bernini-synapse-'$environment
resourceGroup=$environment'-martech-data-rg-eastus2-01'
storageAccountName=$environment'martechrstdsa01'
scope="/subscriptions/$subscription/resourceGroups/$resourceGroup/providers/Microsoft.Storage/storageAccounts/$storageAccountName"

az role assignment create --assignee $assignee --role "Storage Blob Data Reader" --scope $scope