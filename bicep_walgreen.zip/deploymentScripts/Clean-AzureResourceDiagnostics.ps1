<#
.SYNOPSIS
Clean Diagnostics Settings on Azure Resources

.PARAMETER Environment
Specifies envrionment for fetching resource group name

.INPUTS
None. You cannot pipe objects to Clean-AzureResourceDiagnostics.ps1.

.OUTPUTS
The OUTPUT from this script will provide details about resources that are not supported and
when resources are configured with diagnostic settings.

.EXAMPLE
PS> .\Clean-AzureResourceDiagnostics.ps1 -Environment "dev"
#>

param(
  [parameter(Mandatory)]
  [string]$Environment
)

if ( $Environment -notin @("dev", "uat", "prod") ) {
    Throw 'Unknown Environment. Select dev, uat, or prod and try again'
}

# Ensure the Insight provider is enabled on your Azure subscription
$ProviderState = (Get-AzResourceProvider -ProviderNamespace 'microsoft.insights').RegistrationState
if ($ProviderState -contains 'NotRegistered') {
  Throw 'The required resource provider, "microsoft.insights", needs to be enabled on your subscription.'
}

# Gets all the resource groups
$rgs = Get-AzResourceGroup | Where-Object { $_.ResourceGroupName -like "$Environment-martech-*" }

foreach ($rg in $rgs) {
    # Gets all the resources in your resource group
    $resources = Get-AzResource -ResourceGroupName $rg.ResourceGroupName

    foreach ($resource in $resources) {
        Write-Host ''

        # Checks the Diagnostic Setting status for the current resource
        $status = Get-AzDiagnosticSetting -ResourceId $resource.Id -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Where-Object { $_.Name -eq "toLogAnalytics" }
        if ($status) {
            # Removes the Diagnostic Setting for the current resource
            Remove-AzDiagnosticSetting -ResourceId $resource.Id -Verbose -WarningAction SilentlyContinue
        }
    }
}