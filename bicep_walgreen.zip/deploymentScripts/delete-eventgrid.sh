#!/bin/bash

#clean up unnecssary prod resources
# 1 - Eventgrid System Topic - this was a relic of a sample ADF pipeline deployed as a test. It had a blob trigger that created this topic.

resourceGroup='prod-martech-data-rg-eastus2-01'
systemTopicName='prodmartechrstdsa01-ef06dd49-290f-4f1b-9198-ff7375aa0502'

echo 'Deleting eventgrid system topic...'
az eventgrid system-topic delete --name $systemTopicName --resource-group $resourceGroup --yes

if [ "$(az eventgrid system-topic list --resource-group $resourceGroup --query "[?name=='$systemTopicName'] | length(@)")" -eq 0 ]
then 
    echo "Test confirms successful delete of event grid system topic"
else
    echo "Test indicates failed delete of event grid system topic"
fi



