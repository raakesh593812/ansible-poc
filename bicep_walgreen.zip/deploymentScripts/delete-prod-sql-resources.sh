#!/bin/bash

#clean up unnecssary prod resources
# 1 - SQL Server instance originally deployed to support synapse dedicated sql pool dw instance
# 2 - Private endpoint for SQL instance
# 3 - NIC for Private endpoint for SQL instance
# 4 - Eventgrid System Topic - this was a relic of a sample ADF pipeline deployed as a test. It had a blob trigger that created this topic.

resourceGroup='prod-martech-data-rg-eastus2-01'
sqlServerName='prod-martech-sql-01'
privateEndpointName='prod-martech-sql-01-sqlEndpoint'
nicName='prod-martech-sql-01-sqlEndpoint.nic.8054d279-dbea-49dc-9f08-4a5eaf17f3ba'
systemTopicName='prodmartechrstdsa01-ef06dd49-290f-4f1b-9198-ff7375aa0502'
storageAccountName='prodmartechsqlsa01'

echo 'Deleting sql server instance... '
az sql server delete --name $sqlServerName --resource-group $resourceGroup --yes

echo 'Deleting sql server private endpoint...'
az network private-endpoint delete --name $privateEndpointName --resource-group $resourceGroup

echo 'Deleting sql server private endpoint NIC...'
az network nic delete --name $nicName --resource-group $resourceGroup

echo 'Deleting sql server logs storage account...'
az storage account delete --name $storageAccountName --resource-group $resourceGroup --yes

echo 'Deleting eventgrid system topic...'
az eventgrid system-topic delete --name $systemTopicName --resource-group $resourceGroup

if [ "$(az sql server list --resource-group $resourceGroup --query "[?name=='$sqlServerName'] | length(@)")" -eq 0 ]
then 
    echo "Test confirms successful delete of sql server"
else
    echo "Test indicates failed delete of sql server"
fi

if [ "$(az network nic list --resource-group $resourceGroup --query "[?name=='$nicName'] | length(@)")" -eq 0 ]
then 
    echo "Test confirms successful delete of nic"
else
    echo "Test indicates failed delete of nic"
fi

if [ "$(az network private-endpoint list --resource-group $resourceGroup --query "[?name=='$privateEndpointName'] | length(@)")" -eq 0 ]
then 
    echo "Test confirms successful delete of private endpoint"
else
    echo "Test indicates failed delete of private endpoint"
fi

if [ "$(az storage account list --resource-group $resourceGroup --query "[?name=='$storageAccountName'] | length(@)")" -eq 0 ]
then 
    echo "Test confirms successful delete of storage account"
else
    echo "Test indicates failed delete of storage account"
fi

if [ "$(az eventgrid system-topic list --resource-group $resourceGroup --query "[?name=='$systemTopicName'] | length(@)")" -eq 0 ]
then 
    echo "Test confirms successful delete of event grid system topic"
else
    echo "Test indicates failed delete of event grid system topic"
fi



