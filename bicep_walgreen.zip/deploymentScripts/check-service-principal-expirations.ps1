param ([Parameter(Mandatory)] $inputFile, $mode = 'report', [Parameter(Mandatory)] [int] $expiryThreshold, $environment)


Write-Host "Mode is: "$mode

$json = (Get-Content $inputFile -Raw) | ConvertFrom-Json
# $expirationThreshold=60

foreach($servicePrincipal in $json) {
    #2022-07-21T20:53:04.533984+00:00
    $DatePattern = "yyyy-MM-ddTHH:mm:ss.ffffffzzz"
    $credentialExpirations = az ad sp credential list --id $servicePrincipal.principalId --query '[].{EndDate: endDate, KeyId: keyId}' -o json | ConvertFrom-Json
    # $credentialExpirations = Get-AzADApplication -ApplicationId $servicePrincipal.principalId | Get-AzADAppCredential

    if($mode -eq 'report' -or $mode -eq 'alert') {
        Write-Host "Checking Service Principal: $($servicePrincipal.principalId) ($($servicePrincipal.description))"

        if($servicePrincipal.secretId.Length -gt 0) {
            Write-Host "Configuration specifies secret with key" $servicePrincipal.secretId #-ForegroundColor Yellow
        }
        else {
            # Write-Host "Checking secrets for Service Principal:" $servicePrincipal.principalId
        }
    }

    foreach ($credentialExpiration in $credentialExpirations) {
        # Write-Host "Checking Secret Id: " $credentialExpiration.id -ForegroundColor DarkGray
        if($servicePrincipal.secretId.Length -gt 0 -and $credentialExpiration.KeyId -ne $servicePrincipal.secretId){
            # Write-Host "Ids don't match, skipping..." -ForegroundColor DarkGray
        }
        else {
            if($mode -eq 'report') {
                Write-Host "Credential with key:" $credentialExpiration.KeyId "expires on" $credentialExpiration.EndDate
            }
            else {
                $daysTillExpiration=[math]::Round(([DateTime]$credentialExpiration.EndDate - (Get-Date)).TotalDays)

                if($daysTillExpiration -lt $expiryThreshold){
                    Write-Host "Credential with key of" $credentialExpiration.KeyId "expires on" $credentialExpiration.EndDate -ForegroundColor Red
                }
            }
        }
    }
}