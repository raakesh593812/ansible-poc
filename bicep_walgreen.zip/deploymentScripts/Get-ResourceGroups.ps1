param(
  [parameter(Mandatory)]
  [string]$Environment
)

if ( $Environment -notin @("dev", "uat", "prod") ) {
    Throw 'Unknown Environment. Select dev, uat, or prod and try again'
}

# Gets all the resource groups
Get-AzResourceGroup | Where-Object { $_.ResourceGroupName -like "$Environment-martech-*" }
