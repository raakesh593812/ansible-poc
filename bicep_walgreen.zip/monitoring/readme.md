# Monitoring

## Enabling Diagnostics

Resource diagnostics settings can be enabled in scale for the critical resource types. This is powered by a PowerShell script to enable all platform metrics and logs.

You will need to run the `Deploy-AzDiagnostics.ps1` script with along with all appropriate parameters to have diagnostics settings enabled.

> **NOTE**
>
> Currently, diagnostics settings is only supported on the following resource types:
> ```powershell
>$validResourceTypes = @(
>    "Microsoft.DataFactory/factories",
>    "Microsoft.KeyVault/vaults",
>    "Microsoft.Databricks/workspaces",
>    "Microsoft.Network/networkSecurityGroups",
>    "Microsoft.OperationalInsights/workspaces"
>)
>```
> Other resource types will be onboard at a later date.

## Alerts

Alerts will be deployed along with it's respective related resource via the ARM templates. Currently, we are only working with a subset of alerts for now.

Below is a list of alerts per resource:

### Data factory

- ActivityFailedRuns
- PipelineFailedRuns
- TriggerFailedRuns

## Dashboards

Azure dashboards are being used for visualization purposes. While some resources already come with full fledged dashboards upon deployment, others do not. So, are developing custom dashboards using Azure workbooks for resources that do not currently support this natively.

| Resource | Workbook features | Location |
| --- | --- | --- |
| Data Factory | Pipeline, activity, trigger runs, Errors | Azure Monitor |
| Network | Network health, Connectivity, Traffic | Azure monitor |
| Storage accounts | Transactions, Latency, Client Errors | Azure monitor |
| Log analytics | Workspace usage | Azure monitor |

## Monitoring pipeline

A standalone pipeline has been created for testing the Monitoring components. It works similarly to what's documented [here](../README.md).