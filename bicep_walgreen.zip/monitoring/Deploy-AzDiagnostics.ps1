<#
.SYNOPSIS
Configures diagnostics settings on resources

.DESCRIPTION
Configures diagnostics settings on resources

.PARAMETER WorkspaceResourceGroup
The resource group where your log analytics workspace resides

.EXAMPLE
Deploy-AzDiagnostics -WorkspaceResourceGroup <some-name-rg>

.NOTES

#>
function Deploy-AzDiagnostics {
    [CmdletBinding(SupportsShouldProcess)]
    param (
        # Parameter help description
        [Parameter(Mandatory)]
        [string] $WorkspaceResourceGroup,

        [Parameter(Mandatory)]
        [string] $Environment
    )

    begin {
        Write-Debug ("[{0} entered]" -f $MyInvocation.MyCommand)

        # Set appropriate subscription context
        $null = Get-AzContext -ErrorAction Stop
    }

    process {
        # update Az powershell
        #Install-Module Az -Scope CurrentUser -Force

        # Lets validate the workspace information
        Write-Verbose "Getting Log analytics workspace information..." -Verbose
        $workspace = Get-AzOperationalInsightsWorkspace -ResourceGroupName $WorkspaceResourceGroup -ErrorAction Stop | Select-Object -First 1
        if ($workspace) {
            $workspaceId = $workspace.ResourceId
        }
        else {
            Write-Error "Failed to find resource group - $WorkspaceResourceGroup" -ErrorAction Stop
        }

        Write-Verbose "Work space resource Id - $workspaceId" -Verbose

        # Enable subscription diagnostic logs
        $SubscriptionId = $workspaceId.Split("/")[2]
        if (-not (Get-AzDiagnosticSetting -SubscriptionId $SubscriptionId)) {
            $list = @()
            Get-AzSubscriptionDiagnosticSettingCategory | ForEach-Object {
                $list += (New-AzDiagnosticDetailSetting -Log -Category $_.Name -Enabled)
            }

            $DiagnosticSettingName = 'logAnalytics'
            $setting = New-AzDiagnosticSetting -Name $DiagnosticSettingName -SubscriptionId $SubscriptionId -WorkspaceId $WorkspaceId -Setting $list
            Set-AzDiagnosticSetting -InputObject $setting
        }

        # Currently, we are only configuring monitoring for these resource types
        $validResourceTypes = @(
            "Microsoft.DataFactory/factories",
            "Microsoft.KeyVault/vaults",
            "Microsoft.Databricks/workspaces",
            "Microsoft.Network/networkSecurityGroups",
            "Microsoft.OperationalInsights/workspaces"
        )

        foreach ($type in $validResourceTypes) {
            Write-Verbose "Querying resources for resource type - $type" -Verbose

            $getResource = Get-AzResource | Where-Object { ($_.ResourceType -like $type) -and $_.ResourceGroupName -like "$($Environment-martech-*)" }
            foreach ($resource in $getResource) {
                $resourceId = $resource.ResourceId

                Write-Verbose "Enabling diagnostics settings on resource - $resourceId" -Verbose

                # This will enable all diagnostics settings on a resource if Enabled=$true
                $diagSettingsArgs = @{
                    Name        = 'toLogAnalytics'
                    ResourceId  = $resourceId
                    WorkspaceId = $workspaceId
                    Enabled     = $true
                }

                Write-Output ($diagSettingsArgs | Format-Table | Out-String)

                Set-AzDiagnosticSetting @diagSettingsArgs -ExportToResourceSpecific -ErrorAction Continue
            }
        }
    }

    end {
        Write-Debug ("[{0} existed]" -f $MyInvocation.MyCommand)
    }
}
