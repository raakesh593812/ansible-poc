<#
.SYNOPSIS
  This script performs QA tests on your entire repository.

.DESCRIPTION
  This script performs QA tests on your entire repository.
  It will grab all bicep file and build them to ARM JSON for testing.

.EXAMPLE
  PS C:\> tests\QA.tests.ps1

.INPUTS
  Inputs (if any)

.OUTPUTS
  Output (if any)

.NOTES
  General notes
#>

# root folder
$projectDirectory = Split-Path -Path $PSScriptRoot -Parent

# only test files under Src directory
$bicepDirectory = Join-Path -Path $projectDirectory -ChildPath "deployments"
$bicepFiles = Get-ChildItem -Path $bicepDirectory -Recurse -File -Filter *.bicep* -Exclude 'application-old.bicep', 'core-*.bicep', 'vmss.bicep'
$bicepFiles = $bicepFiles.Where{ $_.Length -ne 0 }

# check bicep module is installed
$bicepInstalled = Get-Command -Name bicep -ErrorAction SilentlyContinue
if ($null -eq $bicepInstalled) {
  Write-Error 'Bicep is not installed but is required to run QA. Please install bicep' -ErrorAction Stop
}

# convert all bicep files to arm template (JSON)
foreach ($bicepFile in $bicepFiles.FullName) {
  Write-Output "Building bicep file - $bicepFile"
  bicep build "$bicepFile"
}

# check pester module is installed
$pesterInstalled = Get-Command -Name Invoke-Pester -ErrorAction SilentlyContinue
if ($null -eq $pesterInstalled) {
  Write-Error 'Pester is not installed but is required to run QA. Fix by installing Pester (Install-Module Pester)' -ErrorAction Stop
}

function GetHelpContent {
  param (
    $Path
  )
  $ast = [System.Management.Automation.Language.Parser]::ParseInput((Get-Content -raw $Path), [ref]$null, [ref]$null)
  $ast.GetHelpContent()
}

Describe 'Quality Assurance Tests' {

  BeforeAll {
    if ($null -eq $guid) {
      $script:newGuid = $true
      $guid = [Guid]::NewGuid()
    }

    $script:location = 'eastus2'

    $script:resourceGroupName = "rg-$guid"
    $script:appPrefix = "martech"
    $script:password = -join (((48..57) + (65..90) + (97..122)) * 80 | Get-Random -Count 12 | ForEach-Object { [char]$_ })
  }

  Context 'ARM Template' {
    $templateFiles = Get-ChildItem $bicepDirectory -File -Recurse -Include *.json, *.jsonc -Exclude *parameters*, *example* | ForEach-Object -Process {
      # exclude any json that does not look like an arm template
      if (Get-Content $_.FullName -Raw | Select-String '.*"\$schema":.*management\.azure\.com.*' -Quiet) {
        @{
          File          = $_.FullName
          ConvertedJSON = try {
            Get-Content -Path $_.FullName | ConvertFrom-Json -ErrorAction Stop
          } catch {
            $null
          }
        }
      }
    }

    if ($templateFiles.Count -ge 1) {
      Write-Verbose -Message "ARM Templates found, running QA Tests - [Total - $($templateFiles.File.count)]" -Verbose
      $templateSkip = $false
    } else {
      Write-Verbose -Message 'No ARM Templates found, skipping QA Tests' -Verbose
      $templateSkip = $true
    }

    It 'Converts from JSON | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )

      $ConvertedJSON | Should -Not -BeNullOrEmpty
    }

    # remove files which did not convert from json
    $templateFiles = $templateFiles.Where{ $null -ne $_.ConvertedJSON }

    It 'Has the expected properties | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $expected_elements = @(
        '$schema',
        'contentVersion',
        'parameters',
        #'variables', // commented out since conversion form bicep to ARM removes variable reference if there is none required.
        'resources',
        'outputs'
      )
      $expected_elements | Should -BeIn $ConvertedJSON.PSObject.Properties.Name
    }

    It 'Schema URI should use https and latest apiVersion | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $expectedSchemas = @('https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#', 'https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#', "https://schema.management.azure.com/schemas/2018-05-01/subscriptionDeploymentTemplate.json#")
      $ConvertedJSON.'$schema' | Should -BeIn $expectedSchemas
    }

    It 'Do parameters use camelCasing | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $ConvertedJSON.parameters.PSObject.Properties.Name.ForEach{
        $_ | Should -MatchExactly '^([a-z][0-9]?)+(([A-Z]{1}([a-z]|[0-9]){1}([a-z]|[0-9]?)+)?)+'
      }
    }

    It 'Do parameter types use pascalCase or lower casing | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $ConvertedJSON.parameters.PSObject.Properties.value.type.ForEach{
        $_ | Should -MatchExactly '^([a-z][0-9]?)+(([A-Z]{1}([a-z]|[0-9]){1}([a-z]|[0-9]?)+)?)+'
      }
    }

    <# Commented out since we do not have metadata descriptions in bicep files.
        It 'Every parameter must have a {"metadata" : {"description":""}} element and value | <file>' -TestCases $templateFiles -Skip:$templateSkip {
            param (
                $File,
                $ConvertedJSON
            )
            $ConvertedJSON.parameters.PSObject.Properties.Value | ForEach-Object {
                ($_.metadata.description).count | Should -Be 1
                $_.metadata.description.length | Should -BeGreaterThan 3
            }
        }
        #>

    It 'Do variables use camelCasing | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      if ($ConvertedJSON.variables.PSObject.Properties.Name.Count -gt 0) {
        $ConvertedJSON.variables.PSObject.Properties.Name.ForEach{
          $_ | Should -MatchExactly '^([a-z][0-9]?)+(([A-Z]{1}([a-z]|[0-9]){1}([a-z]|[0-9]?)+)?)+'
        }
      }
    }

    It 'Every resource must have a literal apiVersion | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      if ($ConvertedJSON.resources.Count -gt 0) {
        $ConvertedJSON.resources.ForEach{
          $_.apiVersion | Should -MatchExactly "^\d{4}-\d{2}-\d{2}(-preview)?"
        }
      }
    }

    # It 'Does not have unused parameters defined | <file>' -TestCases $templateFiles -Skip:$templateSkip {
    #     param (
    #         $File,
    #         $ConvertedJSON
    #     )
    #     $rawContent = Get-Content -Path $File -Raw
    #     $ConvertedJSON.parameters.PSObject.Properties.Name.ForEach{
    #         $rawContent | Should -Match "parameters\('$_'\)" -Because "Unused Parameter '$_'"
    #     }
    # }

    # It 'Does not have unused variables defined | <file>' -TestCases $templateFiles -Skip:$templateSkip {
    #     param (
    #         $File,
    #         $ConvertedJSON
    #     )
    #     $rawContent = Get-Content -Path $File -Raw
    #     $ConvertedJSON.variables.PSObject.Properties.Name.ForEach{
    #         # exclude copy variable name
    #         if ($_ -ne 'copy') {
    #             $rawContent | Should -Match "variables\('$_'\)" -Because "Unused Variable '$_'"
    #         }
    #     }
    # }

    It 'Tagging should be implemented - if the resource type supports them | <file>' -TestCases $templateFiles -Skip:$templateSkip {
    }

    It 'Delete lock should be implemented - if the resource type supports it | <file>' -TestCases $templateFiles -Skip:$templateSkip {
    }
  }

  Context 'Test-AzDeployment - Core' {
    #$jsonFile = (Get-ChildItem -Path $bicepDirectory -Recurse -File -Filter 'core.json').FullName

    It "ARM template validation is successful" {

      $coreDeploymentParams = @{
        environmentName                      = 'dev'
        region                               = $script:location
        flowLogsStorageAccountName           = "devmartechnsgflowsa000"
        flowLogsLogAnalyticsName             = "dev-matech-log-000"
        azFirewallIpAddress                  = "10.124.64.4"
        devopsSubnetAddressPrefix            = "10.124.124.32/27"
        spokeVnetAddressSpace                = @(
          "10.124.124.0/24",
          "10.124.119.0/25"
        )
        azServicesSubnetAddressPrefix        = "10.124.119.0/27"
        databricksPrivateSubnetAddressPrefix = "10.124.124.192/26"
        databricksPublicSubnetAddressPrefix  = "10.124.124.128/26"
        appPrefix                            = "$appPrefix"
        TemplateFile                         = "$PSScriptRoot/../deployments/core.json"
        Location                             = $script:location
        Verbose                              = $true
      }
      $result = Test-AzDeployment @coreDeploymentParams
      $result.Message | Should -BeNullOrEmpty
    }
  }

  Context 'Test-AzDeployment - App' {
    #$jsonFile = (Get-ChildItem -Path $bicepDirectory -Recurse -File -Filter 'application.json').FullName

    It "ARM template validation is successful" {
      $appDeploymentParams = @{
        appResourceGroupName        = "paasdemo-app"
        dataFactoryName             = "dev-martech-adf-01"
        actionGroupName             = "dev-martech-ag-01"
        storageAccountName          = "somewbastorgsa001"
        workspaceName               = "dev-martech-log-001"
        networkResourceGroupName    = "dev-martech-network-rg-eastus2-01"
        virtualNetworkName          = "dev-martech-data-vnet-01"
        # sqlServerName               = "dev-martech-sql-01"
        databricksWorkspace         = "dev-martech-dbw-01"
        databricksResourceGroupName = "dev-martech-databricks-rg-eastus2-01"
        environmentName             = "dev"
        region                      = $script:location
        # sqlAdminObjectId            = "b0caa5e6-9ab6-49e9-9c3f-35f140bdc3b1"
        databricksServicePrincipal  = "b0caa5e6-9ab6-49e9-9c3f-35f140bdc3b1"
        # sqlAdminLoginName           = "TAS-DBBI-ADW-ALL"
        voltageUrl                  = "http://localhost"
        # sqlAdminLoginPwd            = $script:password | ConvertTo-SecureString -AsPlainText -Force
        # sqlAuditStorageAccount      = "somewbastorgsa002"
        aadObjectId                 = "01982279-7e5f-4820-9169-aca6650ec0ae"
        keyVaultName                = "somewbakv01"
        appPrefix                   = "$appPrefix"
        TemplateFile                = "$PSScriptRoot/../deployments/application.json"
        Location                    = $script:location
        Verbose                     = $true
      }
      $result = Test-AzDeployment @appDeploymentParams
      $result.Message | Should -BeNullOrEmpty
    }
  }
}
