<#
.SYNOPSIS
  This script performs QA tests on the application components of alcatraz.

.DESCRIPTION
  This script performs QA tests on the application components of alcatraz.

.EXAMPLE
  PS C:\> tests\application.tests.ps1

.INPUTS
  Inputs (if any)

.OUTPUTS
  Output (if any)

.NOTES
  General notes
#>

# root folder
$projectDirectory = Split-Path -Path $PSScriptRoot -Parent

# only test files under Src directory
$bicepDirectory = Join-Path -Path $projectDirectory -ChildPath "../deployments"
$bicepFiles = Get-ChildItem -Path $bicepDirectory -Recurse -File -Filter 'application.bicep'
$bicepFiles = $bicepFiles.Where{ $_.Length -ne 0 }

# check bicep module is installed
$bicepInstalled = Get-Command -Name bicep -ErrorAction SilentlyContinue
if ($null -eq $bicepInstalled) {
  Write-Error 'Bicep is not installed but is required to run QA. Please install bicep' -ErrorAction Stop
}

# convert all bicep files to arm template (JSON)
foreach ($bicepFile in $bicepFiles.FullName) {
  Write-Output "Building bicep file - $bicepFile"
  bicep build "$bicepFile"
}

# check pester module is installed
$pesterInstalled = Get-Command -Name Invoke-Pester -ErrorAction SilentlyContinue
if ($null -eq $pesterInstalled) {
  Write-Error 'Pester is not installed but is required to run QA. Fix by installing Pester (Install-Module Pester)' -ErrorAction Stop
}

Describe 'Martech App Component - Quality Assurance Tests' {

  BeforeAll {
    if ($null -eq $guid) {
      $script:newGuid = $true
      $guid = [Guid]::NewGuid()
    }

    $script:location = 'eastus2'

    $script:resourceGroupName = "rg-$guid"
    $script:appPrefix = "martech"
  }

  Context 'Test-AzDeployment - App' {
    It "ARM template validation is successful" {
      $appDeploymentParams = @{
        appResourceGroupName                    = "paasdemo-app"
        dataFactoryName                         = "dev-martech-adf-01"
        actionGroupName                         = "dev-martech-ag-01"
        storageAccountName                      = "somewbastorgsa001"
        workspaceName                           = "dev-martech-log-001"
        networkResourceGroupName                = "dev-martech-network-rg-eastus2-01"
        virtualNetworkName                      = "dev-martech-data-vnet-01"
        restrictedDatabricksWorkspace           = "dev-martech-dbw-01"
        restrictedDatabricksResourceGroupName   = "dev-martech-databricks-rg-eastus2-01"
        unrestrictedDatabricksWorkspace         = "dev-martech-dbw-02"
        unrestrictedDatabricksResourceGroupName = "dev-martech-databricks-rg-eastus2-01"
        environmentName                         = "dev"
        region                                  = $script:location
        restrictedDatabricksServicePrincipal    = "b0caa5e6-9ab6-49e9-9c3f-35f140bdc3b1"
        unrestrictedDatabricksServicePrincipal  = "c6008845-99c7-4237-8836-2680ab6037f1"
        voltageUrl                              = "http://localhost"
        keyVaultAADObjectId                     = "01982279-7e5f-4820-9169-aca6650ec0ae"
        restrictedKeyVaultName                  = "somereswbakv01"
        unrestrictedKeyVaultName                = "someunreswbakv01"
        appPrefix                               = "$appPrefix"
        TemplateFile                            = "$PSScriptRoot/../../deployments/application.json"
        Location                                = $script:location
        Verbose                                 = $true
      }

      $result = Test-AzDeployment @appDeploymentParams
      $result.Message | Should -BeNullOrEmpty
    }
  }
}
