<#
.SYNOPSIS
  This script performs QA tests on your entire repository.

.DESCRIPTION
  This script performs QA tests on your entire repository.
  It will grab all bicep file and build them to ARM JSON for testing.

.EXAMPLE
  PS C:\> tests\alcatraz.tests.ps1

.INPUTS
  Inputs (if any)

.OUTPUTS
  Output (if any)

.NOTES
  General notes
#>

# root folder
$projectDirectory = Split-Path -Path $PSScriptRoot -Parent

# only test files under Src directory
$bicepDirectory = Join-Path -Path $projectDirectory -ChildPath "../deployments"
$bicepFiles = Get-ChildItem -Path $bicepDirectory -Recurse -File -Filter *.bicep* -Exclude 'application.bicep', 'core.bicep'

# check bicep module is installed
$bicepInstalled = Get-Command -Name bicep -ErrorAction SilentlyContinue
if ($null -eq $bicepInstalled) {
  Write-Error 'Bicep is not installed but is required to run QA. Please install bicep' -ErrorAction Stop
}

# convert all bicep files to arm template (JSON)
foreach ($bicepFile in $bicepFiles.FullName) {
  Write-Output "Building bicep file - $bicepFile"
  bicep build "$bicepFile"
}

# check pester module is installed
$pesterInstalled = Get-Command -Name Invoke-Pester -ErrorAction SilentlyContinue
if ($null -eq $pesterInstalled) {
  Write-Error 'Pester is not installed but is required to run QA. Fix by installing Pester (Install-Module Pester)' -ErrorAction Stop
}

function GetHelpContent {
  param (
    $Path
  )
  $ast = [System.Management.Automation.Language.Parser]::ParseInput((Get-Content -raw $Path), [ref]$null, [ref]$null)
  $ast.GetHelpContent()
}

Describe 'Quality Assurance Tests' {

  Context 'ARM Template' {
    $templateFiles = Get-ChildItem $bicepDirectory -File -Recurse -Include *.json, *.jsonc -Exclude *parameters*, *example* | ForEach-Object -Process {
      # exclude any json that does not look like an arm template
      if (Get-Content $_.FullName -Raw | Select-String '.*"\$schema":.*management\.azure\.com.*' -Quiet) {
        @{
          File          = $_.FullName
          ConvertedJSON = try {
            Get-Content -Path $_.FullName | ConvertFrom-Json -ErrorAction Stop
          } catch {
            $null
          }
        }
      }
    }

    if ($templateFiles.Count -ge 1) {
      Write-Verbose -Message "ARM Templates found, running QA Tests - [Total - $($templateFiles.File.count)]" -Verbose
      $templateSkip = $false
    } else {
      Write-Verbose -Message 'No ARM Templates found, skipping QA Tests' -Verbose
      $templateSkip = $true
    }

    It 'Converts from JSON | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )

      $ConvertedJSON | Should -Not -BeNullOrEmpty
    }

    # remove files which did not convert from json
    $templateFiles = $templateFiles.Where{ $null -ne $_.ConvertedJSON }

    It 'Has the expected properties | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $expected_elements = @(
        '$schema',
        'contentVersion',
        'parameters',
        #'variables', // commented out since conversion form bicep to ARM removes variable reference if there is none required.
        'resources',
        'outputs'
      )
      $expected_elements | Should -BeIn $ConvertedJSON.PSObject.Properties.Name
    }

    It 'Schema URI should use https and latest apiVersion | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $expectedSchemas = @('https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#', 'https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#', "https://schema.management.azure.com/schemas/2018-05-01/subscriptionDeploymentTemplate.json#")
      $ConvertedJSON.'$schema' | Should -BeIn $expectedSchemas
    }

    It 'Do parameters use camelCasing | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $ConvertedJSON.parameters.PSObject.Properties.Name.ForEach{
        $_ | Should -MatchExactly '^([a-z][0-9]?)+(([A-Z]{1}([a-z]|[0-9]){1}([a-z]|[0-9]?)+)?)+'
      }
    }

    It 'Do parameter types use pascalCase or lower casing | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $ConvertedJSON.parameters.PSObject.Properties.value.type.ForEach{
        $_ | Should -MatchExactly '^([a-z][0-9]?)+(([A-Z]{1}([a-z]|[0-9]){1}([a-z]|[0-9]?)+)?)+'
      }
    }

    It 'Every parameter must have a {"metadata" : {"description":""}} element and value | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      $ConvertedJSON.parameters.PSObject.Properties.Value | ForEach-Object {
        ($_.metadata.description).count | Should -Be 1
        $_.metadata.description.length | Should -BeGreaterThan 3
      }
    }

    It 'Do variables use camelCasing | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      if ($ConvertedJSON.variables.PSObject.Properties.Name.Count -gt 0) {
        $ConvertedJSON.variables.PSObject.Properties.Name.ForEach{
          $_ | Should -MatchExactly '^([a-z][0-9]?)+(([A-Z]{1}([a-z]|[0-9]){1}([a-z]|[0-9]?)+)?)+'
        }
      }
    }

    It 'Every resource must have a literal apiVersion | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $ConvertedJSON
      )
      if ($ConvertedJSON.resources.Count -gt 0) {
        $ConvertedJSON.resources.ForEach{
          $_.apiVersion | Should -MatchExactly "^\d{4}-\d{2}-\d{2}(-preview)?"
        }
      }
    }

    It 'Does not have unused parameters defined | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $File,
        $ConvertedJSON
      )
      $rawContent = Get-Content -Path $File -Raw
      $ConvertedJSON.parameters.PSObject.Properties.Name.ForEach{
        $rawContent | Should -Match "parameters\('$_'\)" -Because "Unused Parameter '$_'"
      }
    }

    It 'Does not have unused variables defined | <file>' -TestCases $templateFiles -Skip:$templateSkip {
      param (
        $File,
        $ConvertedJSON
      )
      $rawContent = Get-Content -Path $File -Raw
      $ConvertedJSON.variables.PSObject.Properties.Name.ForEach{
        # exclude copy variable name
        if ($_ -ne 'copy') {
          $rawContent | Should -Match "variables\('$_'\)" -Because "Unused Variable '$_'"
        }
      }
    }

    It 'Tagging should be implemented - if the resource type supports them | <file>' -TestCases $templateFiles -Skip:$templateSkip {
    }

    It 'Delete lock should be implemented - if the resource type supports it | <file>' -TestCases $templateFiles -Skip:$templateSkip {
    }
  }
}
