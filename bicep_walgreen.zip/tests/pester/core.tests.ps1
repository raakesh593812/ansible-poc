<#
.SYNOPSIS
  This script performs QA tests on the core components of alcatraz.

.DESCRIPTION
  This script performs QA tests on the core components of alcatraz.

.EXAMPLE
  PS C:\> tests\core.tests.ps1

.INPUTS
  Inputs (if any)

.OUTPUTS
  Output (if any)

.NOTES
  General notes
#>

# root folder
$projectDirectory = Split-Path -Path $PSScriptRoot -Parent

# only test files under Src directory
$bicepDirectory = Join-Path -Path $projectDirectory -ChildPath "../deployments"
$bicepFiles = Get-ChildItem -Path $bicepDirectory -Recurse -File -Filter 'core.bicep'
$bicepFiles = $bicepFiles.Where{ $_.Length -ne 0 }

# check bicep module is installed
$bicepInstalled = Get-Command -Name bicep -ErrorAction SilentlyContinue
if ($null -eq $bicepInstalled) {
  Write-Error 'Bicep is not installed but is required to run QA. Please install bicep' -ErrorAction Stop
}

# convert all bicep files to arm template (JSON)
foreach ($bicepFile in $bicepFiles.FullName) {
  Write-Output "Building bicep file - $bicepFile"
  bicep build "$bicepFile"
}

# check pester module is installed
$pesterInstalled = Get-Command -Name Invoke-Pester -ErrorAction SilentlyContinue
if ($null -eq $pesterInstalled) {
  Write-Error 'Pester is not installed but is required to run QA. Fix by installing Pester (Install-Module Pester)' -ErrorAction Stop
}

Describe 'Martech Core Component - Quality Assurance Tests' {

  BeforeAll {
    if ($null -eq $guid) {
      $script:newGuid = $true
      $guid = [Guid]::NewGuid()
    }

    $script:location = 'eastus2'
    $script:resourceGroupName = "rg-$guid"
    $script:appPrefix = "martech"
  }

  Context 'Test-AzDeployment - Core' {
    It "ARM template validation is successful" {
      $coreDeploymentParams = @{
        environmentName                                  = 'dev'
        region                                           = $script:location
        firewallIpAddress                                = "10.124.64.4"
        accIaaSSubnetAddressPrefix                       = "10.124.119.32/28"
        devopsSubnetAddressPrefix                        = "10.124.124.32/27"
        spokeVnetAddressSpace                            = @(
          "10.124.124.0/24",
          "10.124.119.0/25"
        )
        azServicesSubnetAddressPrefix                    = "10.124.119.0/27"
        restrictedDatabricksPrivateSubnetAddressPrefix   = "10.124.124.192/26"
        restrictedDatabricksPublicSubnetAddressPrefix    = "10.124.124.128/26"
        unrestrictedDatabricksPrivateSubnetAddressPrefix = "10.124.119.64/26"
        unrestrictedDatabricksPublicSubnetAddressPrefix  = "10.124.124.64/26"
        appPrefix                                        = "$appPrefix"
        TemplateFile                                     = "$PSScriptRoot/../../deployments/core.json"
        Location                                         = $script:location
        Verbose                                          = $true
      }

      $result = Test-AzDeployment @coreDeploymentParams
      $result.Message | Should -BeNullOrEmpty
    }
  }
}
