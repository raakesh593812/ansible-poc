[[_TOC_]]

# Alcatraz Deployment

The reference design is composed of two tiers:

* *Core infrastructure*, which includes the network (topology, traffic segmentation, egress), end-user compute environment, Azure DevOps build server, and a secure configuration baseline via Azure Policy.

* *Application infrastructure*, which includes all Azure resources used for hosting and processing data

The configuration and deployment core and application infrastructure is accomplished via Azure Bicep files, which can be deployed to a subscription with the Azure CLI on a desktop or an Azure DevOps pipeline.

---

## Deploy (Locally)

### Baseline Policies

All Azure policies/governance are based on already defined WBA standards.

### Core Infrastructure

In the `deployments` directory, create a new file called `core.params.json` and enter the parameter values into the file:

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "appPrefix": { "value": "martech" },
    "environment": { "value": "dev" },
    "spokeVnetAddressSpace": { "value": [] },
    "devopsSubnetAddressPrefix": { "value": "" },
    "azServicesSubnetAddressPrefix": { "value": "" },
    "databricksPrivateSubnetAddressPrefix": { "value": "" },
    "databricksPublicSubnetAddressPrefix": { "value": "" },
    "azFirewallIpAddress": { "value": "" }
  }
}
```

Update the following values:

- `spokeVnetAddressSpace`: Set the value for your Virtual network address space
- `devopsSubnetAddressPrefix`: Enter the address prefix (CIDR) for the devops subnet
- `azServicesSubnetAddressPrefix`: Enter the address prefix (CIDR) for the azure services subnet
- `databricksPrivateSubnetAddressPrefix`: Enter the address prefix (CIDR) for the databricks private subnet
- `databricksPublicSubnetAddressPrefix`: Enter the address prefix (CIDR) for the databricks public subnet
- `firewallIpAddress`: Set this to the virtual network appliance IP address

Run the following commands to deploy the core infrastructure:

```bash
az login
bicep build core.bicep
az deployment sub create --name core --location eastus --template-file core.json --parameters core.params.json
```
### Application Infrastructure

In the `deployments` directory, create a new file called `application.params.json` and place the following contents into the file:

```json
{
  "$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentParameters.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
    "region": { "value": "eastus2" },
    "environmentName": { "value": "dev" },
    "appPrefix": { "value": "martech" },
    "voltageUrl": { "value": "" },
    "keyVaultAADObjectId": { "value": "" },
    "databricksServicePrincipal": { "value": "" },
    "tags": {
      "value": {
        "appId": "contoso",
        "costCenter": "abc123"
      }
    }
  }
}
```

Update the following values:

- `databricksServicePrincipal`: SPN for data bricks
- `keyVaultAADObjectId`: SPN for the service principal for key vault access
- `voltageUrl`: Set this to the url for voltage. Required for setting key vault secrets
- `aadObjectId`: Use the following Azure CLI command to find the object ID of the user of group - required for key vault access policy:

  ```bash
  az ad user show --id <sqlAdminLoginName> --query objectId --out tsv
  ```

Next, run the following command to deploy the application tier:

```bash
bicep build application.bicep
az deployment sub create --name application --location eastus2 --template-file application.json --parameters application.params.json
```

---

## Deploy prerequisites via Azure Pipeline

[![Build Status](https://dev.azure.com/WBA/ROCK/_apis/build/status/martech-prereqs?branchName=main)](https://dev.azure.com/WBA/ROCK/_build/latest?definitionId=2302&branchName=main)

### Summary

The perquisites [pipeline](https://dev.azure.com/WBA/ROCK/_build?definitionId=2302) helps to configure Azure Security Center, Azure Defender and some resource providers.

The following resource types are enabled via this pipeline:

```powershell
$requiredResourceProviders = @(
    'Microsoft.Security',
    'Microsoft.EventGrid'
)
```

> **NOTE:** This pipeline might not be necessary for a brownfield environment with security center and Defender already enabled.

---

## Deploy Infra via Azure Pipeline

[![Build Status](https://dev.azure.com/WBA/ROCK/_apis/build/status/Infrastructure/martech.DEPLOY-infra?branchName=feature%2Feroshoko)](https://dev.azure.com/WBA/ROCK/_build/latest?definitionId=3029&branchName=feature%2Feroshoko)

### CI-CD Workflow

Deployments of each components utilized in this solution can be deployed & tested individually in an automated fashion. The full process is as follows:
1. Developer creates a feature branch for changes to code, and pushes changes to the branch.
1. The developer changes trigger a QA test pipeline. [Learn more about QA testing](#arm-template---qa-tests)
1. When the developer is ready for changes to be merged, a PR is created to merge the changes into main.
    - Developer adds the link to the QA pipeline job in the PR description.
1. A team member will review the changes if needed.
1. The PR is then merged to main to complete the loop.

### Prerequisites

In order to utilize the automated deployment pipelines, you need to configure the following:
1. [Bicep CLI](https://github.com/Azure/bicep/blob/main/docs/installing.md) - Compiles Bicep files into ARM templates. Cross-platform.
1. Bicep VS Code Extension - Authoring support, intellisense, validation.
1. Create a Service Principal in Azure
    ```azurecli
    az ad sp create-for-rbac --name "{sp-name}" --sdk-auth --role contributor \
        --scopes /subscriptions/{subscription-id}
    ```
    Replace the following:

      * `{sp-name}` with a suitable name for your service principal, such as the name of the app itself. The name must be unique within your organization.
      * `{subscription-id}` with the subscription ID you want to use (found in Subscriptions in portal)
1. Create a feature branch, following the standard - `feature/<alias>`.
1. Create your [service connection in Azure DevOps](https://docs.microsoft.com/en-us/azure/devops/pipelines/library/connect-to-azure?view=azure-devops).
1. The repository is powered by a configuration file called `global.<environment>.yaml`. The configuration files are used for deployments into the appropriate environment.

    +  Sample `global.dev.yaml`: You can deploy into development/uat environments from any branch.

        ```yaml
        variables:
          # General
            appPrefix: eroshoko                                                                           # Application name as a prefix
            environmentName: dev                                                                          # Application environment
            subscriptionId: xxxxxxxx-b21c-4794-xxxx-f508c89d08c2                                          # Environment subscription Id
            subscriptionName: Microsoft Azure                                                             # Environment subscription name
            serviceConnection: msft-internal                                                              # Service Connection name - Used to authenticate to subscription via SPN
            region: eastus2                                                                               # Deployment region

          # App
            keyVaultAADObjectId: d42edd82-1389-422f-a23d-52a7c6f7ff90                                     # Service Principal object Id for key vault access
            databricksServicePrincipal: d42edd82-1389-422f-a23d-52a7c6f7ff90                              # Data bricks SPN for key vault backed secret scope access

          # Core/Networking
            firewallIpAddress: 10.124.64.4                                                                # NVA appliance IP address
            devopsSubnetAddressPrefix: 10.124.124.32/27                                                   # CIDR for your DevOps build server
            azServicesSubnetAddressPrefix: 10.124.119.0/27                                                # CIDR for Azure Services
            databricksPrivateSubnetAddressPrefix: 10.124.124.128/26                                       # CIDR for Azure Data bricks private (data plane) subnet
            databricksPublicSubnetAddressPrefix: 10.124.124.192/26                                        # CIDR for Azure Data bricks public (control plane) subnet

          # Voltage stuff
            voltageUrl: https://voltage-pp-0000.staging.ent.walgreens.com/policy/clientPolicy.xml         # Voltage server Url for decryption - used as a key vault secret
        ```

        > **NOTE:** Update the values accordingly.
        >
        > The `global.prod.yaml` file is protected by its branch. You can only deploy to the production environment from the `main` branch.
1. All done.

### Pipeline Parameters

The following is a list of parameters needed at runtime to run/provision the environment.

| Parameter | Default Value | Possible Values | Type | Description |
|---|---|---|---|---|
|`environmentName`| `dev` | `dev`, `uat`, `prod` | string | Deployment environment name |
|`component`| `full` | `full`, `app`, `core` | string | Type of component you want to deploy. |

### How to deploy

A YAML [deployment pipeline](https://dev.azure.com/WBA/ROCK/_build?definitionId=3029) has been developed as the CI/CD solution to deploy these policies. Simply select **Run pipeline** and enter the parameter values as required.

---

## ARM Template - QA Tests

[![Build Status](https://dev.azure.com/WBA/ROCK/_apis/build/status/StaticCodeAnalysis-CodeScanning?branchName=feature%2Feroshoko%2Fcleanup)](https://dev.azure.com/WBA/ROCK/_build/latest?definitionId=5324&branchName=main)

Both the `core.bicep`, `application.bicep` & individual modules bicep files are tested vigorously with the help of [Pester](https://pester.dev/). This is done in order to have a consistent, clean and syntactically correct test and to ensure successful deployments.

The tests are split into 3 categories, located in the `tests\pester` folder of the repo to perform syntax validation for ARM template. It runs every time there is a change to the `deployments/*` folder whether in a `feature/*`, `dev` or `main` branch:

- `alcatraz.tests.ps1`: This script tests all module file to make sure they are following ARM standards defined.
- `core.tests.ps1`: This script compiles the `core.bicep` file and performs a `Test-AzDeployment` on the target environment.
- `application.tests.ps1`: This script compiles the `application.bicep` file and performs a `Test-AzDeployment` on the target environment.

The `QA.tests.ps1` script located in `tests` root folder is used to

### Requirements

- PowerShell Core
- Pester 5.1.1
- VSCode

### Usage

#### Pipeline Tasks (PowerShell Core)

```powershell
Install-Module Pester -RequiredVersion 5.1.1 -Force -ErrorAction Stop

Invoke-Pester -Configuration @{
  Run        = @{
    Path = "$(System.DefaultWorkingDirectory)/tests/pester/*.tests.ps1"
  }
  TestResult = @{
    TestSuiteName = 'Solution Tests'
    OutputPath    = '$(System.DefaultWorkingDirectory)/testResults.xml'
    OutputFormat  = 'NUnitXml'
    Enabled       = $true
  }
  Output     = @{
    Verbosity = 'Detailed'
  }
}
```

#### Locally (PowerShell Core)

```powershell
Install-Module Pester -RequiredVersion 5.1.1 -Force -ErrorAction Stop
Invoke-Pester -CI -Output Detailed -Verbose
```

### Unit Tests

For the QA (Unit) tests, we are checking for the following:

- ARM template file converts from json
- Has the expected properties

  ```powershell
  $expected_elements = @(
    '$schema'
    'contentVersion'
    'parameters'
    'variables' # Skipped due to how bicep transposes the conversion from bicep to ARM when variables are not being used.
    'resources'
    'outputs' # Skipped due to how bicep transposes the conversion from bicep to ARM when outputs are not being used.
  )
  ```
- Schema URI should use `https` and latest api version
- Use of camelCasing in the template parameter section
- Use of lowerCasing in the parameter types
- Every parameter must  have a `{"metadata": {"description": ""}}` element and value
- Every resource definition must have a literal `apiVersion`
- Template: `core.bicep` and `application.bicep` are actually deployable.

### Additional resources

- [Pester wiki](https://github.com/Pester/Pester/wiki)
- [Pester setup and commands](https://pester.dev/docs/commands/setup)

## Environment - Code Scanning

Code scanning is a feature that you use to analyze the code in your repository to find security vulnerabilities and coding errors. Any problems identified by the analysis are shown in the pipeline for your investigation.

You can use code scanning to find, triage, and prioritize fixes for existing problems in your code. Code scanning also prevents developers from introducing new problems. You can schedule scans for specific days and times, or trigger scans when a specific event occurs in the repository, such as a push.

In Alcatraz, Code scanning is Powered by [Github super-linter](https://github.com/github/super-linter). We are using this linter to scan for the following script types:

- PowerShell
- Bash
- ARM templates (using [ARM-TTK](https://github.com/azure/arm-ttk))

### Example workflow pipeline

In the repo, there is a `.staticcodeanalysis/pipeline.yaml` file that performs the code scanning based on a trigger (code push).

```yaml
- script: >-
        docker run \
          -e RUN_LOCAL=true \
          -e VALIDATE_POWERSHELL=true \
          -e VALIDATE_ARM=true \
          -e VALIDATE_BASH=true \
          -e FILTER_REGEX_EXCLUDE="(/monitoring/|policies)" \
          -v $(System.DefaultWorkingDirectory):/tmp/lint \
          github/super-linter
      displayName: 'Code Scan via Github Super-Linter'
```
