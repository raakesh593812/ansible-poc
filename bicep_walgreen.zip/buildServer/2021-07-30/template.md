# Virtual Machines

This module deploys one or multiple Virtual Machines Scale sets.

## Resource types

| Resource Type | Api Version
| :-- | :-- |
| `Microsoft.Compute/virtualMachineScaleSets` | 2021-03-01 |
| `Microsoft.KeyVault/vaults/secrets` | 2019-09-01 |
| `Microsoft.Resources/deployments` | 2019-10-01 |

### Resource dependency
The following resources are required to be able to deploy this resource.
- *None*

## Parameters

## Parameters
| Parameter Name | Type | Description | DefaultValue | Possible values |
| :-- | :-- | :-- | :-- | :-- |
| `adminPasswordOrKey` | secureString | SSH Key or password for the Virtual Machine. SSH key is recommended. | `password` |  |
| `adminUsername` | string | Admin username for VMSS. | `groot` |  |
| `agentOrgUrl` | string | The URL of the Azure DevOps organization. | `https://dev.azure.com/wba` |  |
| `agentPat` | secureString | The Personal Access Token (PAT) used to configure the agent. |  |  |
| `agentPool` | string | The name of the Agent Pool where the agent should register. |  |  |
| `appPrefix` | string | Deployment app prefix |  |  |
| `environmentName` | string | Deployment environment name |  | `dev`, `uat`, `perf`, `prod` |
| `existingVnetName` | string | vName of the existing virtual network to deploy the scale set into. | `[format('{0}-{1}-data-vnet-01', parameters('environmentName'), parameters('appPrefix'))]` |  |
| `existingVnetResourceGroupName` | string | Name of the resourceGroup for the existing virtual network to deploy the scale set into. |  |  |
| `keyVaultName` | string | Key vault resource name | `[format('{0}-{1}-kv-01', parameters('environmentName'), parameters('appPrefix'))]` |  |
| `keyVaultResourceGroup` | string | Existing application Key vault resource group name | `[format('{0}-{1}-data-rg-{2}-01', parameters('environmentName'), parameters('appPrefix'), parameters('region'))]` |  |
| `managedImageResourceGroup` | string | Managed image resource group name | `[format('{0}-{1}-buildsvr-rg-{2}-01', parameters('environmentName'), parameters('appPrefix'), parameters('region'))]` |  |
| `region` | string | Deployment region. | `eastus2` |  |
| `tags` | object | Optional. Tags of the VM resource. | `{}` |  |

### Parameter Usage: `tags`

Tag names and tag values can be provided as needed. A tag can be left without a value.

```json
"tags": {
  "type": "object",
  "defaultValue": {
    "CostCenter": "Marketing Technology",
    "LegalSubEntity": "Walgreen Co",
    "Sensitivity": "Non-Sensitive",
    "SubDivision": "Digital Engineering",
    "Department": "Digital Engineering",
    "SenType": "Not-Applicable"
  }
}
```

## Outputs

| Output Name | Type | Description |
| :-- | :-- | :-- |
| `vmssName` | string |  |

## Considerations

*N/A*

## Additional resources

## Additional resources

- [Use tags to organize your Azure resources](https://docs.microsoft.com/en-us/azure/azure-resource-manager/resource-group-using-tags)
- [Azure Resource Manager template reference](https://docs.microsoft.com/en-us/azure/templates/)
- [Deployments](https://docs.microsoft.com/en-us/azure/templates/Microsoft.Resources/2019-10-01/deployments)
