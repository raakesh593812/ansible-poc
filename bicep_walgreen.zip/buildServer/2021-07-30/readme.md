This page describes how to deploy a linux custom image and use it with a ScaleSet for Build Agents.

[[_TOC_]]

# Custom Image

Image build process is powered by [Packer](https://www.packer.io/)

## Installed Components

| OS |   |   | Linux |
| -  | - | - | - |
| Base Image | | | `UbuntuServer 18.04-LTS` |
| Software | `Azure-CLI` |  | :heavy_check_mark: |
| | `PowerShell Core (7.*)` | | :heavy_check_mark:  |
| | `Docker CE` | | :heavy_check_mark: |
| | `bicep` | | :heavy_check_mark: |
|
| Modules
| | PowerShell
| | | `PowerShellGet` | :heavy_check_mark: |
| | | `Pester` | :heavy_check_mark: |
| | | `PSScriptAnalyzer` | :heavy_check_mark: |
| | | `powershell-yaml` | :heavy_check_mark: |
| | | `Az.*` | :heavy_check_mark: |
| Extensions
| | CLI
| | | `azure-devops` | :heavy_check_mark: |
---
---

# Scale Set Agents

The scale set agents deployment includes several components:

| Resource | Description |
|--|--|
| Resource Group | The resource group hosting our scale set resources |
| Virtual Machine Scale Set | The scale set that will host our pipeline agents |


## Advantages

> Compared to classic single build host (with multiple agents installed)
- Each pipeline job can use a dedicated new host (if configured accordingly)
- We can safe money as the scale set can be configured to e.g. scale down to 0 and spin up a new VM only if a job is scheduled
  - As a single agent is installed on a new instance, VMs don't have to have a strong SKU

---

## Use in DevOps

In general the process works as follows:
1. Deploy a VMSS to Azure
   Create a VMSS and select the previously created custom image as the base image. Make sure the scaling is configured as `'manual'`. The amount of initial VMs does not matter as they are scaled down anyways.
1. Register the VMSS from Azure DevOps
    - Navigate to the ADO project / Project Settings / Agent Pools and create a new Agent Pool.
      - As a type select VMSS and further select the created VMSS
      - Configure further properties like the amount of instances at rest (can be 0) or that you want to read down agents after every use (for that to work make sure the MaxCount is sufficiently high - otherwise it still reuses idle agents)
    - Subsequently an extension is applied by ADO to the VMSS that takes care of registering the agents. ADO will also take care of the scaling as per the configured values
    - Now you can reference the created pool in your pipelines
      - With the image provided in this solution it takes
        - About 8 Minutes for a Windows Agent to come to life
        - About 4 Minutes for a Linux Agent to come to life

---

## Additional Considerations


### Apply a new image

The image used in the scale set can be idempotently updated. Once a new image is available just restart the ScaleSet deployment pipeline and wait for it to complete.
New build agents will be based on the new image.

---
# Sources

- [VMSS for ADO agents](https://docs.microsoft.com/en-us/azure/devops/pipelines/agents/scale-set-agents?view=azure-devops)
